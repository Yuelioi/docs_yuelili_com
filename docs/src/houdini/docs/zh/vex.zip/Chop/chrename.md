---
title: chrename
order: 21
category:
  - vex
---



Context(s)
[chop](../contexts/chop.html)

`int chrename(int channel\_index, string new\_name)`

`int chrename(string channel\_name, string new\_name)`

This function renames a CHOP channel . It works only when iterating over Clip, Channel or Samples, not when iterating over ChannelSample.

Returns 1 if channel was renamed or 0 otherwise.

## Arguments

`channel_index`

The channel index to rename.

`channel_name`

The channel to rename.

`new_name`

The new name.


chop

[chadd](chadd.html)

[chattr](chattr.html)

[chattrnames](chattrnames.html)

[chend](chend.html)

[chendf](chendf.html)

[chendt](chendt.html)

[chindex](chindex.html)

[chinput](chinput.html)

[chinputlimits](chinputlimits.html)

[chname](chname.html)

[chnames](chnames.html)

[chnumchan](chnumchan.html)

[chop](chop.html)

[choplocal](choplocal.html)

[choplocalt](choplocalt.html)

[chopt](chopt.html)

[chrate](chrate.html)

[chreadbuf](chreadbuf.html)

[chremove](chremove.html)

[chremoveattr](chremoveattr.html)

[chrename](chrename.html)

[chresizebuf](chresizebuf.html)

[chsetattr](chsetattr.html)

[chsetlength](chsetlength.html)

[chsetrate](chsetrate.html)

[chsetstart](chsetstart.html)

[chstart](chstart.html)

[chstartf](chstartf.html)

[chstartt](chstartt.html)

[chwritebuf](chwritebuf.html)

[isframes](isframes.html)

[issamples](issamples.html)

[isseconds](isseconds.html)
