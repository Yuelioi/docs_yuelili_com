---
title: qmultiply
order: 53
category:
  - vex
---

`vector4 qmultiply(vector4 q1, vector4 q2)`

Multiplies two quaternions and returns the result.


quaternion

[dihedral](dihedral.html)

[eulertoquaternion](eulertoquaternion.html)

[qconvert](qconvert.html)

[qdistance](qdistance.html)

[qinvert](qinvert.html)

[qmultiply](qmultiply.html)

[qrotate](qrotate.html)

[quaternion](quaternion.html)

[quaterniontoeuler](quaterniontoeuler.html)

[slerp](slerp.html)
