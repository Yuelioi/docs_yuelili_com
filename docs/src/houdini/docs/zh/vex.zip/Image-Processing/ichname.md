---
title: ichname
order: 15
category:
  - vex
---



Context(s)
[cop](../contexts/cop.html)

`string ichname(int inputnum, int plane\_index, int component\_index)`

Returns the component name (for example, “r” or “x”) of a component of a plane.


input_plane

[iaspect](iaspect.html)

[ichname](ichname.html)

[iend](iend.html)

[iendtime](iendtime.html)

[ihasplane](ihasplane.html)

[inumplanes](inumplanes.html)

[iplaneindex](iplaneindex.html)

[iplanename](iplanename.html)

[iplanesize](iplanesize.html)

[irate](irate.html)

[istart](istart.html)

[istarttime](istarttime.html)

[ixres](ixres.html)

[iyres](iyres.html)
