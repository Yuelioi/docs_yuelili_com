---
title: hasplane
order: 13
category:
  - vex
---



Context(s)
[cop](../contexts/cop.html)

`int hasplane(string planename)`

Returns 1 if the plane specified by the parameter exists in this COP.


output_plane

[alphaname](alphaname.html)

[bumpname](bumpname.html)

[chname](chname.html)

[colorname](colorname.html)

[depthname](depthname.html)

[hasplane](hasplane.html)

[lumname](lumname.html)

[maskname](maskname.html)

[normalname](normalname.html)

[planeindex](planeindex.html)

[planename](planename.html)

[planesize](planesize.html)

[pointname](pointname.html)

[velocityname](velocityname.html)
