---
title: istart
order: 24
category:
  - vex
---



Context(s)
[cop](../contexts/cop.html)

`int istart(int opinput)`

## Arguments

`opinput`

The input number to read from, starting from 0. For example, the first input is 0, the second input is 1, and so on.

## Returns

The starting frame of the specified input.


input_plane

[iaspect](iaspect.html)

[ichname](ichname.html)

[iend](iend.html)

[iendtime](iendtime.html)

[ihasplane](ihasplane.html)

[inumplanes](inumplanes.html)

[iplaneindex](iplaneindex.html)

[iplanename](iplanename.html)

[iplanesize](iplanesize.html)

[irate](irate.html)

[istart](istart.html)

[istarttime](istarttime.html)

[ixres](ixres.html)

[iyres](iyres.html)
