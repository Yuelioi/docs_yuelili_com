---
title: accessframe
order: 2
category:
  - vex
---



Context(s)
[cop](../contexts/cop.html)

`void accessframe(int frame)`



## See also

- [Time Machine](../../nodes/cop2/tima.html)
- [Time Filter](../../nodes/cop2/timefilter.html)
