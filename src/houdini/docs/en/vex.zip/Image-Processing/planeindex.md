---
title: planeindex
order: 33
category:
  - vex
---

Context(s)
[cop](../contexts/cop.html)

`int planeindex(string planename)`

Returns the index of the plane specified by the parameter, starting at
zero.

output_plane

[alphaname](alphaname.html)

[bumpname](bumpname.html)

[chname](chname.html)

[colorname](colorname.html)

[depthname](depthname.html)

[hasplane](hasplane.html)

[lumname](lumname.html)

[maskname](maskname.html)

[normalname](normalname.html)

[planeindex](planeindex.html)

[planename](planename.html)

[planesize](planesize.html)

[pointname](pointname.html)

[velocityname](velocityname.html)
