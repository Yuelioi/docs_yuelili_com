---
title: keys
order: 4
category:
  - vex
---

Since

18.5

`string [] keys(dict d)`

Returns all the keys in the dictionary. Returns an empty string array
if the dictionary is empty. The returned keys are always sorted
alphabetically.
