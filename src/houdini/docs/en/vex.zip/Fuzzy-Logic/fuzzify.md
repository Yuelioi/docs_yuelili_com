---
title: fuzzify
order: 2
category:
  - vex
---

`float fuzzify(string ramp\_basis[], float ramp\_values[], float ramp\_positions[], float crisp\_value, float min\_value, float max\_value)`

Converts a crisp value to a fuzzy value based on an input membership function.

fuzzy

[fuzzify](fuzzify.html)

[fuzzy_and](fuzzy_and.html)

[fuzzy_defuzz_centroid](fuzzy_defuzz_centroid.html)

[fuzzy_nand](fuzzy_nand.html)

[fuzzy_nor](fuzzy_nor.html)

[fuzzy_not](fuzzy_not.html)

[fuzzy_nxor](fuzzy_nxor.html)

[fuzzy_or](fuzzy_or.html)

[fuzzy_xor](fuzzy_xor.html)

|
math

[Du](Du.html)

[Dv](Dv.html)

[Dw](Dw.html)

[abs](abs.html)

[acos](acos.html)

[asin](asin.html)

[atan](atan.html)

[atten](atten.html)

[avg](avg.html)

[cbrt](cbrt.html)

[ceil](ceil.html)

[cos](cos.html)

[cosh](cosh.html)

[cracktransform](cracktransform.html)

[cross](cross.html)

[degrees](degrees.html)

[dot](dot.html)

[erf](erf.html)

[erf_inv](erf_inv.html)

[erfc](erfc.html)

[exp](exp.html)

[floor](floor.html)

[frac](frac.html)

[fuzzify](fuzzify.html)

[getderiv](getderiv.html)

[isfinite](isfinite.html)

[isnan](isnan.html)

[log](log.html)

[log10](log10.html)

[max](max.html)

[min](min.html)

[pow](pow.html)

[product](product.html)

[radians](radians.html)

[resample_linear](resample_linear.html)

[rint](rint.html)

[shl](shl.html)

[shr](shr.html)

[shrz](shrz.html)

[sign](sign.html)

[sin](sin.html)

[sinh](sinh.html)

[solvecubic](solvecubic.html)

[solvepoly](solvepoly.html)

[solvequadratic](solvequadratic.html)

[solvetriangleSSS](solvetriangleSSS.html)

[sqrt](sqrt.html)

[sum](sum.html)

[tan](tan.html)

[tanh](tanh.html)

[trunc](trunc.html)

[variance](variance.html)
