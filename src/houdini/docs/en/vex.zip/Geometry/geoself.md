---
title: geoself
order: 7
category:
  - vex
---

`int geoself()`

Returns a handle to the current geometry, suitable for the geometry creation operations.

util

[geoself](geoself.html)
