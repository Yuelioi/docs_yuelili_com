---
title: Accessing Camera & Light Information
order: 18
category:
  - AE 插件开发
---

# Accessing Camera & Light Information

Using functions provided in the [AEGP_PFInterfaceSuite](../aegps/aegp-suites.html) (#aegps-aegp-suites-aegp-pfinterfacesuite), effects can access camera and lighting information for the layer to which they’re applied; see the Resizer sample.

You can also use many of the other functions from AE_GeneralPlug.h; the possibilities are vast.
