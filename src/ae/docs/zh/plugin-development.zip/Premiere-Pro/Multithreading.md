---
title: Multithreading
order: 5
category:
  - AE 插件开发
---

# Multithreading

You may have noticed this flag: `PF_OutFlag2_PPRO_DO_NOT_CLONE_SEQUENCE_DATA_FOR_RENDER`. We advise against setting this flag, as it has been found to cause parameter UI problems.
