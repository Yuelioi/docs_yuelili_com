---
title: Effect Basics
order: 2
category:
  - AE 插件开发
---

# Effect Basics

This chapter will provide all the information you need to know to understand how a basic effect plug-in works.

These details are fundamental to every effect plug-in.

By the time you finish this chapter, you’ll be ready for the fun stuff; modifying pixels!
