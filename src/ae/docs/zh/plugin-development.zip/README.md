1. 把 \\_ 替换成 _
2. `<span class="pre">` 和 ` 删掉 </span>`
3. Tip 提示框
