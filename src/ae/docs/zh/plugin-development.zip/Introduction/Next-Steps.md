---
title: Next Steps
order: 18
category:
  - AE 插件开发
---

# Next Steps

You now have an understanding of what plug-ins are, what they can do, and how After Effects communicates with them.

Next, we will cover the [basics of effects plug-ins](../effect-basics/effect-basics.html) (#effect-basics-effect-basics).
