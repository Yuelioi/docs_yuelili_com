# Other Math¶

## degreesToRadians(`degrees`)¶

**Description**

Converts degrees to radians.

**Parameters**

|Property|Type|
|---|---|
|`degrees`|Number  |
**Type**

Number

* * *

## radiansToDegrees(`radians`)¶

**Description**

Converts radians to degrees.

**Parameters**

|Property|Type|
|---|---|
|`radians`|Number  |
**Type**

Number

