import{_ as t}from"./_plugin-vue_export-helper.cdc0426e.js";import{o as p,c as l,a as n,b as s,e,f as i,r as c}from"./app.d29ede9e.js";const o={},u=n("h2",{id:"\u5BF9\u5E94\u5B98\u65B9\u6587\u6863\u94FE\u63A5",tabindex:"-1"},[n("a",{class:"header-anchor",href:"#\u5BF9\u5E94\u5B98\u65B9\u6587\u6863\u94FE\u63A5","aria-hidden":"true"},"#"),s(" \u5BF9\u5E94\u5B98\u65B9\u6587\u6863\u94FE\u63A5")],-1),d={href:"https://docs.blender.org/api/master/bpy.ops.html",target:"_blank",rel:"noopener noreferrer"},r={href:"https://www.yuelili.com/docs/blender-master/overview-of-action-items/",target:"_blank",rel:"noopener noreferrer"},v={href:"https://docs.blender.org/api/master/bpy.types.Operator.html",target:"_blank",rel:"noopener noreferrer"},m=i(`<h3 id="\u5E94\u7528\u64CD\u4F5C\u9879" tabindex="-1"><a class="header-anchor" href="#\u5E94\u7528\u64CD\u4F5C\u9879" aria-hidden="true">#</a> \u5E94\u7528\u64CD\u4F5C\u9879</h3><p>\u7528 python \u8BBF\u95EE\u64CD\u4F5C\u9879 \uFF0C\u5305\u62EC C\u3001Python \u6216\u5B8F\u7F16\u5199\u7684\u64CD\u4F5C\u9879\u3002</p><p>\u53EA\u6709\u5173\u952E\u5B57\u53C2\u6570\u53EF\u7528\u4E8E\u4F20\u9012\u64CD\u4F5C\u9879\u5C5E\u6027\u3002</p><p>\u64CD\u4F5C\u9879\u8FD4\u56DE\u4E00\u4E2A set() \uFF0C\u5B83\u7531\u4EE5\u4E0B\u90E8\u5206\u7EC4\u6210\uFF1A<code>{&#39;RUNNING_MODAL&#39;, &#39;CANCELLED&#39;, &#39;FINISHED&#39;,&#39;PASS_THROUGH&#39;}</code> \u3002\u5E38\u89C1\u7684\u8FD4\u56DE\u503C\u662F<code>{&#39;FINISHED&#39;}\`\`{&#39;CANCELLED&#39;}</code></p><p>\u5728\u9519\u8BEF\u573A\u666F\u8C03\u7528\u64CD\u4F5C\u9879\u4F1A\u5F15\u53D1<code>RuntimeError</code>\uFF0C\u53EF\u4EE5\u4F7F\u7528 poll() \u65B9\u6CD5\u907F\u514D\u3002\uFF08\u6BD4\u5982\u4F60\u5728\u7269\u4F53\u6A21\u5F0F\u79FB\u52A8\u201C\u7F16\u8F91\u6A21\u5F0F\u201D\u4E0B\u7684\u70B9\uFF09</p><h4 id="\u5173\u952E\u5B57\u548C\u4F4D\u7F6E\u53C2\u6570" tabindex="-1"><a class="header-anchor" href="#\u5173\u952E\u5B57\u548C\u4F4D\u7F6E\u53C2\u6570" aria-hidden="true">#</a> \u5173\u952E\u5B57\u548C\u4F4D\u7F6E\u53C2\u6570</h4><p>\u5173\u952E\u5B57\u5BF9\u5E94\u64CD\u4F5C\u9879 <strong>\u5C5E\u6027</strong> \uFF0C\u4F4D\u7F6E\u53C2\u6570\u7528\u4E8E\u5B9A\u4E49\u64CD\u4F5C\u9879\u7684 <strong>\u8C03\u7528\u65B9\u5F0F</strong> \u3002</p><p>\u6709 3 \u4E2A\u53EF\u9009\u7684\u4F4D\u7F6E\u53C2\u6570\uFF08\u4E0B\u9762\u8BE6\u7EC6\u8BB0\u5F55\uFF09\u3002</p><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code>bpy<span class="token punctuation">.</span>ops<span class="token punctuation">.</span>test<span class="token punctuation">.</span>operator<span class="token punctuation">(</span>override_context<span class="token punctuation">,</span> execution_context<span class="token punctuation">,</span> undo<span class="token punctuation">)</span>

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div></div></div><ul><li>override_context \uFF1A\u8986\u5199\uFF0C<code>dict</code>\u7C7B\u578B\u3002</li><li>execution_context \uFF1A\u6267\u884C\u533A\u57DF\uFF0C <code>str</code>\uFF08\u679A\u4E3E\uFF09\u3002</li><li>undo \uFF1A\u64A4\u9500\uFF0C<code>bool</code>\u7C7B\u578B\u3002</li></ul><p>\u4E0A\u9762\u6BCF\u4E2A\u90FD\u662F\u53EF\u9009\u7684\uFF0C\u4F46\u5FC5\u987B\u6309\u7167\u987A\u5E8F\u4E66\u5199\u3002</p><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code><span class="token keyword">import</span> bpy

<span class="token comment"># \u8C03\u7528\u64CD\u4F5C\u9879</span>
bpy<span class="token punctuation">.</span>ops<span class="token punctuation">.</span>mesh<span class="token punctuation">.</span>subdivide<span class="token punctuation">(</span>number_cuts<span class="token operator">=</span><span class="token number">3</span><span class="token punctuation">,</span> smoothness<span class="token operator">=</span><span class="token number">0.5</span><span class="token punctuation">)</span>


<span class="token comment"># \u7528poll()\u68C0\u67E5\u5DE5\u4F5C\u533A \u907F\u514D\u53D1\u751F\u610F\u5916.</span>
<span class="token keyword">if</span> bpy<span class="token punctuation">.</span>ops<span class="token punctuation">.</span><span class="token builtin">object</span><span class="token punctuation">.</span>mode_set<span class="token punctuation">.</span>poll<span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">:</span>
    bpy<span class="token punctuation">.</span>ops<span class="token punctuation">.</span><span class="token builtin">object</span><span class="token punctuation">.</span>mode_set<span class="token punctuation">(</span>mode<span class="token operator">=</span><span class="token string">&#39;EDIT&#39;</span><span class="token punctuation">)</span>

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="\u8986\u76D6\u4E0A\u4E0B\u6587" tabindex="-1"><a class="header-anchor" href="#\u8986\u76D6\u4E0A\u4E0B\u6587" aria-hidden="true">#</a> \u8986\u76D6\u4E0A\u4E0B\u6587</h3><p>\u8986\u76D6\u64CD\u4F5C\u9879\u7684\u4E0A\u4E0B\u6587\u6210\u5458\u3002\u8FD9\u6837\u53EF\u4EE5\u4E0D\u4EC5\u9650\u4E8E\u64CD\u4F5C\u5F53\u524D\u9879\u3002</p><p>\u53EF\u4EE5\u6269\u5145 <strong>\u5F71\u54CD\u8303\u56F4</strong> \uFF0C\u6BD4\u5982\u4ECE\u5F53\u524D\u9009\u62E9\u9879 \u2192 \u5168\u90E8\u5BF9\u8C61\uFF08\u89C1\u793A\u4F8B\uFF09\u3002\u8FD8\u53EF\u4EE5\u63D0\u5347\u4F5C\u7528\u7A7A\u95F4\uFF0C\u672C\u6765\u5728\u7269\u4F53\u6A21\u5F0F\u8FD0\u884C\uFF0C\u73B0\u5728\u53EF\u4EE5\u6269\u5C55\u5230\u5176\u4ED6\u6A21\u5F0F\u3002</p><p>\u4E0A\u4E0B\u6587\u8986\u76D6\u4F5C\u4E3A\u5B57\u5178\u4F20\u9012\uFF0C\u952E\u540D\u8981\u4E0E bpy.context \u4E2D\u7684\u4E0A\u4E0B\u6587\u6210\u5458\u540D\u5339\u914D\u3002\u6BD4\u5982\u8986\u76D6 active_object\uFF08<code>bpy.context.active_object</code>\uFF09\uFF0C\u9700\u8981\u4F7F\u7528<code>{&#39;active_object&#39;: object}</code>\u3002X[\u952E\u540D] = \u65B0\u7684\u4F5C\u7528\u6210\u5458</p><p>::: tip \u5927\u5BB6\u90FD\u5E0C\u671B\u4F7F\u7528\u5F53\u524D\u4E0A\u4E0B\u6587\u7684\u526F\u672C\u4F5C\u4E3A\u57FA\u7840\uFF08\u4E0D\u7136\u8FD8\u5F97\u81EA\u5DF1\u68C0\u7D22\u6570\u636E\uFF09\u3002 :::</p><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code><span class="token comment"># \u8986\u5199\uFF1A\u5220\u9664\u5F53\u524D\u5BF9\u8C61 \u2192 \u5220\u9664\u573A\u666F\u4E2D\u6240\u6709\u5BF9\u8C61</span>
<span class="token keyword">import</span> bpy

<span class="token comment"># \u590D\u5236\u4E00\u4EFDcontext\uFF0C\u56E0\u4E3Acontext\u53EA\u80FD\u8BFB</span>
override <span class="token operator">=</span> bpy<span class="token punctuation">.</span>context<span class="token punctuation">.</span>copy<span class="token punctuation">(</span><span class="token punctuation">)</span>
<span class="token comment"># \u8986\u5199\uFF1A\u628A\u5F53\u524D\u9009\u62E9\u7684\u5BF9\u8C61\u53D8\u6210\u573A\u666F\u4E2D\u6240\u6709\u5BF9\u8C61</span>
override<span class="token punctuation">[</span><span class="token string">&#39;selected_objects&#39;</span><span class="token punctuation">]</span> <span class="token operator">=</span> <span class="token builtin">list</span><span class="token punctuation">(</span>bpy<span class="token punctuation">.</span>context<span class="token punctuation">.</span>scene<span class="token punctuation">.</span>objects<span class="token punctuation">)</span>
<span class="token comment"># \u6267\u884C\u5220\u9664\uFF1A\u6B64\u65F6\u5220\u9664\u5F53\u524D \u2192 \u5220\u9664\u5168\u90E8</span>
bpy<span class="token punctuation">.</span>ops<span class="token punctuation">.</span><span class="token builtin">object</span><span class="token punctuation">.</span>delete<span class="token punctuation">(</span>override<span class="token punctuation">)</span>

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="\u6267\u884C\u4E0A\u4E0B\u6587" tabindex="-1"><a class="header-anchor" href="#\u6267\u884C\u4E0A\u4E0B\u6587" aria-hidden="true">#</a> \u6267\u884C\u4E0A\u4E0B\u6587</h3><p>\u8C03\u7528\u64CD\u4F5C\u9879\u65F6\uFF0C\u6267\u884C\u4E0A\u4E0B\u6587\u7684\u54EA\u4E9B\u5185\u5BB9\u3002</p><p>\u51B3\u5B9A\u64CD\u4F5C\u9879\u7684\u8FD0\u884C\u73AF\u5883\uFF0C\u4EE5\u53CA\u662F\u8C03\u7528 invoke() \u8FD8\u662F\u53EA\u8C03\u7528 execute()\u7B49\u7B49\u3002</p><p>\u9ED8\u8BA4\u60C5\u51B5\u4E0B\u4F7F\u7528<code>EXEC_DEFAULT</code>\uFF0C\u4EC5\u8FD0\u884C<code>execute()</code>\u65B9\u6CD5\uFF0C\u5982\u679C\u5B58\u5728<code>INVOKE_DEFAULT</code>\u5C06\u8C03\u7528 invoke()\u3002</p><p>\u6267\u884C\u4E0A\u4E0B\u6587\u8303\u56F4\uFF1A</p><ul><li><code>INVOKE_DEFAULT</code> \uFF1A\u53EA\u6267\u884C invoke()</li><li><code>INVOKE_REGION_WIN</code>\uFF1A</li><li><code>INVOKE_REGION_CHANNELS</code>\uFF1A</li><li><code>INVOKE_REGION_PREVIEW</code>\uFF1A</li><li><code>INVOKE_AREA</code>\uFF1A</li><li><code>INVOKE_SCREEN</code>\uFF1A</li><li><code>EXEC_DEFAULT</code>\uFF1A\u53EA\u6267\u884C execute()</li><li><code>EXEC_REGION_WIN</code>\uFF1A</li><li><code>EXEC_REGION_CHANNELS</code>\uFF1A</li><li><code>EXEC_REGION_PREVIEW</code>\uFF1A</li><li><code>EXEC_AREA</code>\uFF1A</li><li><code>EXEC_SCREEN</code>\uFF1A</li></ul><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code><span class="token comment">## \u53EA\u6267\u884Cinvoke\u51FD\u6570</span>
<span class="token keyword">import</span> bpy
bpy<span class="token punctuation">.</span>ops<span class="token punctuation">.</span><span class="token builtin">object</span><span class="token punctuation">.</span>collection_instance_add<span class="token punctuation">(</span><span class="token string">&#39;INVOKE_DEFAULT&#39;</span><span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>\u4E5F\u53EF\u4EE5\u5728\u7528\u6237\u754C\u9762\u7684\u7279\u5B9A\u4F4D\u7F6E\u8FD0\u884C\u3002\u4E3A\u6B64\uFF0C\u6211\u4EEC\u9700\u8981\u4F20\u9012\u7A97\u53E3\u3001\u5C4F\u5E55\u3001\u533A\u57DF\uFF0C\u6709\u65F6\u8FD8\u9700\u8981\u4F20\u9012\u4E00\u4E2A\u533A\u57DF\u3002</p><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code><span class="token comment"># \u6240\u6709\u7A97\u53E3\u76843D\u89C6\u56FE\u90FD\u6700\u5927\u5316\u663E\u793A</span>
<span class="token keyword">import</span> bpy

<span class="token keyword">for</span> window <span class="token keyword">in</span> bpy<span class="token punctuation">.</span>context<span class="token punctuation">.</span>window_manager<span class="token punctuation">.</span>windows<span class="token punctuation">:</span>
    screen <span class="token operator">=</span> window<span class="token punctuation">.</span>screen

    <span class="token keyword">for</span> area <span class="token keyword">in</span> screen<span class="token punctuation">.</span>areas<span class="token punctuation">:</span>
        <span class="token keyword">if</span> area<span class="token punctuation">.</span><span class="token builtin">type</span> <span class="token operator">==</span> <span class="token string">&#39;VIEW_3D&#39;</span><span class="token punctuation">:</span>
            override <span class="token operator">=</span> <span class="token punctuation">{</span><span class="token string">&#39;window&#39;</span><span class="token punctuation">:</span> window<span class="token punctuation">,</span> <span class="token string">&#39;screen&#39;</span><span class="token punctuation">:</span> screen<span class="token punctuation">,</span> <span class="token string">&#39;area&#39;</span><span class="token punctuation">:</span> area<span class="token punctuation">}</span>
            bpy<span class="token punctuation">.</span>ops<span class="token punctuation">.</span>screen<span class="token punctuation">.</span>screen_full_area<span class="token punctuation">(</span>override<span class="token punctuation">)</span>
            <span class="token keyword">break</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="\u547D\u540D\u89C4\u5219" tabindex="-1"><a class="header-anchor" href="#\u547D\u540D\u89C4\u5219" aria-hidden="true">#</a> \u547D\u540D\u89C4\u5219</h3><p><img src="https://cdn.yuelili.com/20220113084517.png" alt=""></p><table><thead><tr><th>Property</th><th>\u7F29\u5199</th><th>\u540D\u79F0</th></tr></thead><tbody><tr><td>bpy.types.Operator</td><td>OT</td><td>\u64CD\u4F5C\u9879</td></tr><tr><td>---</td><td>---</td><td>---</td></tr><tr><td>bpy.types.Panel</td><td>PT</td><td>\u9762\u677F</td></tr><tr><td>bpy.types.Header</td><td>HT</td><td>Header</td></tr><tr><td>bpy.types.MENU</td><td>MT</td><td>\u83DC\u5355</td></tr><tr><td>bpy.types.UIList</td><td>UL</td><td>UI \u5217\u8868</td></tr></tbody></table>`,30),k={href:"https://docs.blender.org/api/master/bpy.types.Operator.html",target:"_blank",rel:"noopener noreferrer"},b=i(`<h3 id="\u6700\u7B80\u5355\u7684\u64CD\u4F5C\u9879" tabindex="-1"><a class="header-anchor" href="#\u6700\u7B80\u5355\u7684\u64CD\u4F5C\u9879" aria-hidden="true">#</a> \u6700\u7B80\u5355\u7684\u64CD\u4F5C\u9879</h3><p>\u4E00\u4E2A\u7B80\u5355\u7684\u64CD\u4F5C\u9879\uFF0C\u53EF\u4EE5\u6253\u5370\u4E00\u6761\u4FE1\u606F\u3002</p><p>\u7531\u4E8E\u8BE5\u64CD\u4F5C\u9879\u53EA\u6709\u4E00\u4E2A Operator.execute \u51FD\u6570\uFF0C\u6240\u4EE5\u4E0D\u9700\u8981\u7528\u6237\u8F93\u5165\u3002</p><p>::: tip \u5728 blender \u8BBF\u95EE\u64CD\u4F5C\u9879\u7684\u5B50\u7C7B\u4E4B\u524D\uFF0C\u5FC5\u987B\u5148\u6CE8\u518C\u3002 :::</p><p><img src="https://cdn.yuelili.com/20220113132251.png" alt=""></p><p><em>\u5728\u63A7\u5236\u53F0\u4F7F\u7528 bl_idname \u8FDB\u884C\u8BBF\u95EE</em></p><p><img src="https://cdn.yuelili.com/20220113132225.png" alt=""></p><p><em>\u7528 F3 \u641C\u7D22\uFF0C\u4F7F\u7528 bl_label \u8FDB\u884C\u8BBF\u95EE</em></p><p><img src="https://cdn.yuelili.com/20220113133343.png" alt=""></p><p><em>\u6DFB\u52A0\u5230\u89C6\u56FE\u83DC\u5355(view)\uFF0C\u53EF\u4EE5\u76F4\u63A5\u5728\u6700\u4E0B\u9762\u770B\u5230</em></p><p>\u4EE3\u7801\uFF1A</p><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code><span class="token keyword">import</span> bpy

<span class="token keyword">class</span> <span class="token class-name">HelloWorldOperator</span><span class="token punctuation">(</span>bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>Operator<span class="token punctuation">)</span><span class="token punctuation">:</span>
    bl_idname <span class="token operator">=</span> <span class="token string">&quot;wm.hello_world&quot;</span> <span class="token comment"># id, \u53EF\u4EE5\u5728\u63A7\u5236\u53F0\u4F7F\u7528\uFF0C\u6216\u8005\u88AB\u5176\u4ED6\u7C7B\u8C03\u7528</span>
    bl_label <span class="token operator">=</span> <span class="token string">&quot;\u6700\u8F7B\u91CF\u7684\u64CD\u4F5C\u9879&quot;</span>   <span class="token comment"># \u663E\u793A\u540D\u79F0\uFF0C\u4F7F\u7528F3\u641C\u7D22bl_label\uFF0C\u53EF\u4EE5\u67E5\u627E\u64CD\u4F5C\u9879</span>

    <span class="token comment"># \u8981\u6267\u884C\u7684\u51FD\u6570</span>
    <span class="token keyword">def</span> <span class="token function">execute</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
        <span class="token keyword">print</span><span class="token punctuation">(</span><span class="token string">&quot;Hello World&quot;</span><span class="token punctuation">)</span>
        <span class="token keyword">return</span> <span class="token punctuation">{</span><span class="token string">&#39;FINISHED&#39;</span><span class="token punctuation">}</span>

<span class="token comment"># \u5982\u679C\u60F3\u52A0\u5165\u52A8\u6001\u83DC\u5355</span>
<span class="token keyword">def</span> <span class="token function">menu_func</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
    self<span class="token punctuation">.</span>layout<span class="token punctuation">.</span>operator<span class="token punctuation">(</span>HelloWorldOperator<span class="token punctuation">.</span>bl_idname<span class="token punctuation">,</span> text<span class="token operator">=</span><span class="token string">&quot;\u6211\u5728\u8FD9\u513F&quot;</span><span class="token punctuation">)</span>

<span class="token comment"># \u6CE8\u518C\uFF08\u5FC5\u987B\u6CE8\u518C\uFF09</span>
bpy<span class="token punctuation">.</span>utils<span class="token punctuation">.</span>register_class<span class="token punctuation">(</span>HelloWorldOperator<span class="token punctuation">)</span>

<span class="token comment"># \u6DFB\u52A0\u5230\u89C6\u56FE\u83DC\u5355\u4E2D</span>
bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>VIEW3D_MT_view<span class="token punctuation">.</span>append<span class="token punctuation">(</span>menu_func<span class="token punctuation">)</span>


</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="invoke-\u8C03\u7528\u51FD\u6570" tabindex="-1"><a class="header-anchor" href="#invoke-\u8C03\u7528\u51FD\u6570" aria-hidden="true">#</a> Invoke \u8C03\u7528\u51FD\u6570</h3><p>invoke()\u901A\u5E38\u7528\u4E8E\u5206\u914D\u5C5E\u6027\uFF0C\u7136\u540E\u7531 execute()\u6765\u4F7F\u7528\u3002</p><p>\u6709\u4E9B\u8FD0\u7B97\u7B26\u6CA1\u6709 execute()\u51FD\u6570\uFF0C\u5C31\u6CA1\u6CD5\u91CD\u590D\u4F7F\u7528\u8FD9\u4E2A\u51FD\u6570\u4E86\u3002</p><p>\u672C\u4F8B\u5C55\u793A\u5B9A\u4E49\u4E00\u4E2A\u64CD\u4F5C\u9879\uFF0C\u83B7\u53D6\u9F20\u6807\u8F93\u5165\u6765\u6267\u884C\u4E00\u4E2A\u51FD\u6570\u3002\u5E76\u4E14\u8FD9\u4E2A\u64CD\u4F5C\u9879\u53EF\u4EE5\u4ECE python api \u4E2D\u8C03\u7528\u6216\u6267\u884C\u3002</p><p>\u8FD9\u4E2A\u64CD\u4F5C\u9879\u8FD8\u5B9A\u4E49\u4E86\u81EA\u5DF1\u7684\u5C5E\u6027\uFF0C\u8FD9\u4E9B\u5C5E\u6027\u4E0E\u5178\u578B\u7684\u7C7B\u5C5E\u6027\u4E0D\u540C\uFF0C\u56E0\u4E3A Blender \u5C06\u5B83\u4EEC\u4E0E\u64CD\u4F5C\u7B26\u6CE8\u518C\u5728\u4E00\u8D77\uFF0C\u5728\u8C03\u7528\u65F6\u4F5C\u4E3A\u53C2\u6570\u4F7F\u7528\uFF0C\u4E3A\u64CD\u4F5C\u7B26\u7684\u64A4\u9500/\u91CD\u505A\u4FDD\u5B58\uFF0C\u5E76\u81EA\u52A8\u6DFB\u52A0\u5230\u7528\u6237\u754C\u9762\u3002</p><p><img src="https://cdn.yuelili.com/20220113134937.png" alt=""></p><p><em>\u64CD\u4F5C\u9879\u63D0\u793A\u533A</em></p><p><img src="https://cdn.yuelili.com/20220113135317.png" alt=""></p><p><em>report \u4FE1\u606F\u5C55\u793A</em></p><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code><span class="token keyword">import</span> bpy


<span class="token keyword">class</span> <span class="token class-name">SimpleMouseOperator</span><span class="token punctuation">(</span>bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>Operator<span class="token punctuation">)</span><span class="token punctuation">:</span>
    <span class="token triple-quoted-string string">&quot;&quot;&quot; \u672C\u64CD\u4F5C\u9879\u663E\u793A\u9F20\u6807\u4F4D\u7F6E ,
        \u8FD9\u91CC\u540C\u65F6\u4E5F\u662Fapi\u63D0\u793A\u533A
    &quot;&quot;&quot;</span>


    bl_idname <span class="token operator">=</span> <span class="token string">&quot;wm.mouse_position&quot;</span>
    bl_label <span class="token operator">=</span> <span class="token string">&quot;Invoke Mouse Operator&quot;</span>

    <span class="token comment"># \u5B9A\u4E49\u4FE9\u6574\u578B\u53D8\u91CF</span>
    x<span class="token punctuation">:</span> bpy<span class="token punctuation">.</span>props<span class="token punctuation">.</span>IntProperty<span class="token punctuation">(</span><span class="token punctuation">)</span>
    y<span class="token punctuation">:</span> bpy<span class="token punctuation">.</span>props<span class="token punctuation">.</span>IntProperty<span class="token punctuation">(</span><span class="token punctuation">)</span>

    <span class="token keyword">def</span> <span class="token function">execute</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
        <span class="token comment"># \u4F7F\u7528report\u51FD\u6570\u663E\u793A\u7ED3\u679C,</span>
        self<span class="token punctuation">.</span>report<span class="token punctuation">(</span><span class="token punctuation">{</span><span class="token string">&#39;INFO&#39;</span><span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token string">&quot;\u9F20\u6807\u5F53\u524D\u4F4D\u4E8E %d %d&quot;</span> <span class="token operator">%</span> <span class="token punctuation">(</span>self<span class="token punctuation">.</span>x<span class="token punctuation">,</span> self<span class="token punctuation">.</span>y<span class="token punctuation">)</span><span class="token punctuation">)</span>
        <span class="token keyword">return</span> <span class="token punctuation">{</span><span class="token string">&#39;FINISHED&#39;</span><span class="token punctuation">}</span>

    <span class="token keyword">def</span> <span class="token function">invoke</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">,</span> event<span class="token punctuation">)</span><span class="token punctuation">:</span>
        self<span class="token punctuation">.</span>x <span class="token operator">=</span> event<span class="token punctuation">.</span>mouse_x
        self<span class="token punctuation">.</span>y <span class="token operator">=</span> event<span class="token punctuation">.</span>mouse_y
        <span class="token keyword">return</span> self<span class="token punctuation">.</span>execute<span class="token punctuation">(</span>context<span class="token punctuation">)</span>

<span class="token comment"># \u52A8\u6001\u6DFB\u52A0\u51FD\u6570</span>
<span class="token keyword">def</span> <span class="token function">menu_func</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
    self<span class="token punctuation">.</span>layout<span class="token punctuation">.</span>operator<span class="token punctuation">(</span>SimpleMouseOperator<span class="token punctuation">.</span>bl_idname<span class="token punctuation">,</span> text<span class="token operator">=</span><span class="token string">&quot;Simple Mouse Operator&quot;</span><span class="token punctuation">)</span>

<span class="token comment"># \u6CE8\u518C\u5E76\u6DFB\u52A0\u5230view\u9762\u677F</span>
bpy<span class="token punctuation">.</span>utils<span class="token punctuation">.</span>register_class<span class="token punctuation">(</span>SimpleMouseOperator<span class="token punctuation">)</span>
bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>VIEW3D_MT_view<span class="token punctuation">.</span>append<span class="token punctuation">(</span>menu_func<span class="token punctuation">)</span>


<span class="token comment"># \u4F7F\u7528\u672C\u51FD\u6570</span>
bpy<span class="token punctuation">.</span>ops<span class="token punctuation">.</span>wm<span class="token punctuation">.</span>mouse_position<span class="token punctuation">(</span><span class="token string">&#39;INVOKE_DEFAULT&#39;</span><span class="token punctuation">)</span>

<span class="token comment"># \u4F7F\u7528\u672C\u51FD\u6570\uFF08\u5E76\u81EA\u5E26\u53C2\u6570\uFF09</span>
<span class="token comment"># bpy.ops.wm.mouse_position(&#39;EXEC_DEFAULT&#39;, x=20, y=66)</span>


</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="\u8C03\u7528\u6587\u4EF6\u9009\u62E9\u5668" tabindex="-1"><a class="header-anchor" href="#\u8C03\u7528\u6587\u4EF6\u9009\u62E9\u5668" aria-hidden="true">#</a> \u8C03\u7528\u6587\u4EF6\u9009\u62E9\u5668</h3><p>\u672C\u4F8B\u5C55\u793A\u5982\u4F55\u4F7F\u7528\u6587\u4EF6\u9009\u62E9\u5668\u3002\uFF08window_manager.fileselect_add\uFF09</p><p>invoke \u51FD\u6570\u8C03\u7528\u4E86\u4E00\u4E2A\u7A97\u53E3\u7BA1\u7406\u5668\uFF08window manager\uFF09\u65B9\u6CD5\uFF0C\u5E76\u8FD4\u56DE <code>{&#39;RUNNING_MODAL&#39;}</code>,\u6A21\u5F0F\u3002\u6B64\u65F6\u6587\u4EF6\u9009\u62E9\u5668\u5C06\u6301\u7EED\u8FD0\u884C\uFF0C\u76F4\u5230 invoke \u7ED3\u675F\u3002</p><p>\u8FD0\u884C\u6587\u4EF6\u9009\u62E9\u5668\uFF0C\u7528\u6237\u786E\u8BA4\u540E\uFF0C\u5C06\u8C03\u7528 <code>Operator.execute</code> \u3002</p><p>Operator.poll \u51FD\u6570\u53EF\u9009\uFF0C\u7528\u4E8E\u68C0\u67E5\u64CD\u4F5C\u9879\u662F\u5426\u53EF\u4EE5\u8FD0\u884C\uFF08\u4F5C\u7528\u8303\u56F4\uFF09\u3002</p><p><img src="https://cdn.yuelili.com/20220113140243.png" alt=""></p><p><img src="https://cdn.yuelili.com/20220113140159.png" alt=""></p><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code><span class="token keyword">import</span> bpy


<span class="token keyword">class</span> <span class="token class-name">ExportSomeData</span><span class="token punctuation">(</span>bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>Operator<span class="token punctuation">)</span><span class="token punctuation">:</span>
    <span class="token triple-quoted-string string">&quot;&quot;&quot;\u6D4B\u8BD5\u6587\u4EF6\u9009\u62E9\u5668&quot;&quot;&quot;</span>
    bl_idname <span class="token operator">=</span> <span class="token string">&quot;export.some_data&quot;</span>
    bl_label <span class="token operator">=</span> <span class="token string">&quot;Export Some Data&quot;</span>

    filepath<span class="token punctuation">:</span> bpy<span class="token punctuation">.</span>props<span class="token punctuation">.</span>StringProperty<span class="token punctuation">(</span>subtype<span class="token operator">=</span><span class="token string">&quot;FILE_PATH&quot;</span><span class="token punctuation">)</span>

    <span class="token decorator annotation punctuation">@classmethod</span>
    <span class="token keyword">def</span> <span class="token function">poll</span><span class="token punctuation">(</span>cls<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
        <span class="token keyword">return</span> context<span class="token punctuation">.</span><span class="token builtin">object</span> <span class="token keyword">is</span> <span class="token keyword">not</span> <span class="token boolean">None</span>

    <span class="token keyword">def</span> <span class="token function">execute</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
        <span class="token builtin">file</span> <span class="token operator">=</span> <span class="token builtin">open</span><span class="token punctuation">(</span>self<span class="token punctuation">.</span>filepath<span class="token punctuation">,</span> <span class="token string">&#39;w&#39;</span><span class="token punctuation">)</span>
        <span class="token builtin">file</span><span class="token punctuation">.</span>write<span class="token punctuation">(</span><span class="token string">&quot;Hello World &quot;</span> <span class="token operator">+</span> context<span class="token punctuation">.</span><span class="token builtin">object</span><span class="token punctuation">.</span>name<span class="token punctuation">)</span>
        <span class="token keyword">return</span> <span class="token punctuation">{</span><span class="token string">&#39;FINISHED&#39;</span><span class="token punctuation">}</span>

    <span class="token keyword">def</span> <span class="token function">invoke</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">,</span> event<span class="token punctuation">)</span><span class="token punctuation">:</span>
        <span class="token comment"># \u4F7F\u7528\u4E00\u4E0B window_manager</span>
        context<span class="token punctuation">.</span>window_manager<span class="token punctuation">.</span>fileselect_add<span class="token punctuation">(</span>self<span class="token punctuation">)</span>
        <span class="token keyword">return</span> <span class="token punctuation">{</span><span class="token string">&#39;RUNNING_MODAL&#39;</span><span class="token punctuation">}</span>



<span class="token keyword">def</span> <span class="token function">menu_func</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
    self<span class="token punctuation">.</span>layout<span class="token punctuation">.</span>operator_context <span class="token operator">=</span> <span class="token string">&#39;INVOKE_DEFAULT&#39;</span>
    self<span class="token punctuation">.</span>layout<span class="token punctuation">.</span>operator<span class="token punctuation">(</span>ExportSomeData<span class="token punctuation">.</span>bl_idname<span class="token punctuation">,</span> text<span class="token operator">=</span><span class="token string">&quot;Text Export Operator&quot;</span><span class="token punctuation">)</span>


bpy<span class="token punctuation">.</span>utils<span class="token punctuation">.</span>register_class<span class="token punctuation">(</span>ExportSomeData<span class="token punctuation">)</span>
bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>TOPBAR_MT_file_export<span class="token punctuation">.</span>append<span class="token punctuation">(</span>menu_func<span class="token punctuation">)</span>


<span class="token comment"># \u6D4B\u8BD5\u8C03\u7528</span>
bpy<span class="token punctuation">.</span>ops<span class="token punctuation">.</span>export<span class="token punctuation">.</span>some_data<span class="token punctuation">(</span><span class="token string">&#39;INVOKE_DEFAULT&#39;</span><span class="token punctuation">)</span>

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="dialog-box-\u5BF9\u8BDD\u7A97\u53E3" tabindex="-1"><a class="header-anchor" href="#dialog-box-\u5BF9\u8BDD\u7A97\u53E3" aria-hidden="true">#</a> Dialog Box \u5BF9\u8BDD\u7A97\u53E3</h3><p>\u4F7F\u7528<code>Operator.invoke</code>\u51FD\u6570\u8C03\u7528\u5F39\u51FA\u7A97\u53E3\u3002\u4F7F\u7528\u4E86\uFF08window_manager.invoke_props_dialog\uFF09</p><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code><span class="token keyword">import</span> bpy


<span class="token keyword">class</span> <span class="token class-name">DialogOperator</span><span class="token punctuation">(</span>bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>Operator<span class="token punctuation">)</span><span class="token punctuation">:</span>
    bl_idname <span class="token operator">=</span> <span class="token string">&quot;object.dialog_operator&quot;</span>
    bl_label <span class="token operator">=</span> <span class="token string">&quot;\u7B80\u5355\u7684\u5BF9\u8BDD\u6846&quot;</span>

    my_float<span class="token punctuation">:</span> bpy<span class="token punctuation">.</span>props<span class="token punctuation">.</span>FloatProperty<span class="token punctuation">(</span>name<span class="token operator">=</span><span class="token string">&quot;\u4E00\u4E2A\u6D6E\u70B9\u6570&quot;</span><span class="token punctuation">)</span>
    my_bool<span class="token punctuation">:</span> bpy<span class="token punctuation">.</span>props<span class="token punctuation">.</span>BoolProperty<span class="token punctuation">(</span>name<span class="token operator">=</span><span class="token string">&quot;\u5F00/\u5173&quot;</span><span class="token punctuation">)</span>
    my_string<span class="token punctuation">:</span> bpy<span class="token punctuation">.</span>props<span class="token punctuation">.</span>StringProperty<span class="token punctuation">(</span>name<span class="token operator">=</span><span class="token string">&quot;\u4E00\u4E2A\u5B57\u7B26\u4E32&quot;</span><span class="token punctuation">)</span>

    <span class="token keyword">def</span> <span class="token function">execute</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
        message <span class="token operator">=</span> <span class="token punctuation">(</span>
            <span class="token string">&quot;\u7528\u6237\u8F93\u5165\u4E86: %f, %d, &#39;%s&#39;&quot;</span> <span class="token operator">%</span>
            <span class="token punctuation">(</span>self<span class="token punctuation">.</span>my_float<span class="token punctuation">,</span> self<span class="token punctuation">.</span>my_bool<span class="token punctuation">,</span> self<span class="token punctuation">.</span>my_string<span class="token punctuation">)</span>
        <span class="token punctuation">)</span>
        self<span class="token punctuation">.</span>report<span class="token punctuation">(</span><span class="token punctuation">{</span><span class="token string">&#39;INFO&#39;</span><span class="token punctuation">}</span><span class="token punctuation">,</span> message<span class="token punctuation">)</span>
        <span class="token keyword">return</span> <span class="token punctuation">{</span><span class="token string">&#39;FINISHED&#39;</span><span class="token punctuation">}</span>

    <span class="token keyword">def</span> <span class="token function">invoke</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">,</span> event<span class="token punctuation">)</span><span class="token punctuation">:</span>
        wm <span class="token operator">=</span> context<span class="token punctuation">.</span>window_manager
        <span class="token keyword">return</span> wm<span class="token punctuation">.</span>invoke_props_dialog<span class="token punctuation">(</span>self<span class="token punctuation">)</span>


<span class="token keyword">def</span> <span class="token function">menu_func</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
    self<span class="token punctuation">.</span>layout<span class="token punctuation">.</span>operator<span class="token punctuation">(</span>DialogOperator<span class="token punctuation">.</span>bl_idname<span class="token punctuation">,</span> text<span class="token operator">=</span><span class="token string">&quot;Dialog Operator&quot;</span><span class="token punctuation">)</span>


bpy<span class="token punctuation">.</span>utils<span class="token punctuation">.</span>register_class<span class="token punctuation">(</span>DialogOperator<span class="token punctuation">)</span>
bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>VIEW3D_MT_object<span class="token punctuation">.</span>append<span class="token punctuation">(</span>menu_func<span class="token punctuation">)</span>

<span class="token comment"># \u6D4B\u8BD5\u8C03\u7528</span>
bpy<span class="token punctuation">.</span>ops<span class="token punctuation">.</span><span class="token builtin">object</span><span class="token punctuation">.</span>dialog_operator<span class="token punctuation">(</span><span class="token string">&#39;INVOKE_DEFAULT&#39;</span><span class="token punctuation">)</span>

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="\u81EA\u5B9A\u4E49\u7ED8\u5236" tabindex="-1"><a class="header-anchor" href="#\u81EA\u5B9A\u4E49\u7ED8\u5236" aria-hidden="true">#</a> \u81EA\u5B9A\u4E49\u7ED8\u5236</h3><p>\u9ED8\u8BA4\u60C5\u51B5\u4E0B\uFF0C\u64CD\u4F5C\u9879\u5C5E\u6027\u81EA\u52A8\u4F7F\u7528\u7528\u6237\u754C\u9762\u5E03\u5C40\u3002\u5982\u679C\u9700\u8981\u66F4\u591A\u63A7\u5236\uFF0C\u53EF\u4EE5\u4F7F\u7528<code>Operator.draw</code>\u51FD\u6570\u521B\u5EFA\u81EA\u5B9A\u4E49\u5E03\u5C40 \u3002</p><p>\u8FD9\u7C7B\u4F3C\u4E8E<code>Panel</code>\u548C<code>Menu</code>\u7ED8\u5236\u51FD\u6570\uFF0C\u4E5F\u53EF\u7528\u4E8E\u5BF9\u8BDD\u6846\u548C\u6587\u4EF6\u9009\u62E9\u5668\u3002</p><p>\u793A\u4F8B\uFF1A\u5F39\u51FA\u81EA\u5B9A\u4E49\u6846</p><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code><span class="token keyword">import</span> bpy


<span class="token keyword">class</span> <span class="token class-name">CustomDrawOperator</span><span class="token punctuation">(</span>bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>Operator<span class="token punctuation">)</span><span class="token punctuation">:</span>
    bl_idname <span class="token operator">=</span> <span class="token string">&quot;object.custom_draw&quot;</span>
    bl_label <span class="token operator">=</span> <span class="token string">&quot;\u7B80\u5355\u7684Modal\u64CD\u4F5C\u9879&quot;</span>

    filepath<span class="token punctuation">:</span> bpy<span class="token punctuation">.</span>props<span class="token punctuation">.</span>StringProperty<span class="token punctuation">(</span>subtype<span class="token operator">=</span><span class="token string">&quot;FILE_PATH&quot;</span><span class="token punctuation">)</span>

    my_float<span class="token punctuation">:</span> bpy<span class="token punctuation">.</span>props<span class="token punctuation">.</span>FloatProperty<span class="token punctuation">(</span>name<span class="token operator">=</span><span class="token string">&quot;\u6D6E\u70B9X&quot;</span><span class="token punctuation">)</span>
    my_bool<span class="token punctuation">:</span> bpy<span class="token punctuation">.</span>props<span class="token punctuation">.</span>BoolProperty<span class="token punctuation">(</span>name<span class="token operator">=</span><span class="token string">&quot;\u5F00\u5173Y&quot;</span><span class="token punctuation">)</span>
    my_string<span class="token punctuation">:</span> bpy<span class="token punctuation">.</span>props<span class="token punctuation">.</span>StringProperty<span class="token punctuation">(</span>name<span class="token operator">=</span><span class="token string">&quot;\u5B57\u7B26\u4E32Z&quot;</span><span class="token punctuation">)</span>

    <span class="token keyword">def</span> <span class="token function">execute</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
        <span class="token keyword">print</span><span class="token punctuation">(</span><span class="token string">&quot;Test&quot;</span><span class="token punctuation">,</span> self<span class="token punctuation">)</span>
        <span class="token keyword">return</span> <span class="token punctuation">{</span><span class="token string">&#39;FINISHED&#39;</span><span class="token punctuation">}</span>

    <span class="token keyword">def</span> <span class="token function">invoke</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">,</span> event<span class="token punctuation">)</span><span class="token punctuation">:</span>
        wm <span class="token operator">=</span> context<span class="token punctuation">.</span>window_manager
        <span class="token keyword">return</span> wm<span class="token punctuation">.</span>invoke_props_dialog<span class="token punctuation">(</span>self<span class="token punctuation">)</span>

    <span class="token keyword">def</span> <span class="token function">draw</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
        <span class="token comment"># \u521B\u5EFA\u5E03\u5C40</span>
        layout <span class="token operator">=</span> self<span class="token punctuation">.</span>layout

        <span class="token comment"># \u7B2C\u4E00\u884C</span>
        col <span class="token operator">=</span> layout<span class="token punctuation">.</span>column<span class="token punctuation">(</span><span class="token punctuation">)</span>
        col<span class="token punctuation">.</span>label<span class="token punctuation">(</span>text<span class="token operator">=</span><span class="token string">&quot;\u6211\u7684\u81EA\u5B9A\u4E49\u754C\u9762&quot;</span><span class="token punctuation">)</span>

        <span class="token comment"># \u7B2C\u4E8C\u884C row \u6A2A\u5411\u5E03\u5C40</span>
        row <span class="token operator">=</span> col<span class="token punctuation">.</span>row<span class="token punctuation">(</span><span class="token punctuation">)</span>
        row<span class="token punctuation">.</span>prop<span class="token punctuation">(</span>self<span class="token punctuation">,</span> <span class="token string">&quot;my_float&quot;</span><span class="token punctuation">)</span>
        row<span class="token punctuation">.</span>prop<span class="token punctuation">(</span>self<span class="token punctuation">,</span> <span class="token string">&quot;my_bool&quot;</span><span class="token punctuation">)</span>

        <span class="token comment"># \u7B2C\u4E09\u884C</span>
        col<span class="token punctuation">.</span>prop<span class="token punctuation">(</span>self<span class="token punctuation">,</span> <span class="token string">&quot;my_string&quot;</span><span class="token punctuation">)</span>

<span class="token keyword">def</span> <span class="token function">menu_func</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
    self<span class="token punctuation">.</span>layout<span class="token punctuation">.</span>operator<span class="token punctuation">(</span>CustomDrawOperator<span class="token punctuation">.</span>bl_idname<span class="token punctuation">,</span> text<span class="token operator">=</span><span class="token string">&quot;Custom Draw Operator&quot;</span><span class="token punctuation">)</span>

bpy<span class="token punctuation">.</span>utils<span class="token punctuation">.</span>register_class<span class="token punctuation">(</span>CustomDrawOperator<span class="token punctuation">)</span>
bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>VIEW3D_MT_object<span class="token punctuation">.</span>append<span class="token punctuation">(</span>menu_func<span class="token punctuation">)</span>

<span class="token comment"># \u6D4B\u8BD5</span>
bpy<span class="token punctuation">.</span>ops<span class="token punctuation">.</span><span class="token builtin">object</span><span class="token punctuation">.</span>custom_draw<span class="token punctuation">(</span><span class="token string">&#39;INVOKE_DEFAULT&#39;</span><span class="token punctuation">)</span>

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="modal-\u6A21\u6001\u6267\u884C" tabindex="-1"><a class="header-anchor" href="#modal-\u6A21\u6001\u6267\u884C" aria-hidden="true">#</a> Modal \u6A21\u6001\u6267\u884C</h3><p>\u5B9A\u4E49\u4E00\u4E2A<code>Operator.modal</code>\u51FD\u6570\uFF0C\u8BE5\u51FD\u6570\u5C06\u7EE7\u7EED\u6301\u7EED\u5904\u7406\u67D0\u4E2A\u4E8B\u4EF6\uFF0C\u76F4\u5230\u8FD4\u56DE<code>{&#39;FINISHED&#39;}</code>\u6216<code>{&#39;CANCELLED&#39;}</code>\uFF0C\u65B9\u53EF\u505C\u6B62\u8BE5\u5BF9\u8BDD\u3002</p><p>\u6BCF\u6B21\u68C0\u6D4B\u5230\u65B0\u4E8B\u4EF6\uFF08\u4F8B\u5982\u9F20\u6807\u5355\u51FB\u6216\u6309\u952E\uFF09\u65F6\uFF0C\u90FD\u4F1A\u8FD0\u884C\u6A21\u6001\u64CD\u4F5C\u9879\u3002\u76F8\u53CD\uFF0C\u6CA1\u6709\u68C0\u6D4B\u5230\u65B0\u4E8B\u4EF6\u65F6\uFF0C\u6A21\u6001\u64CD\u4F5C\u9879\u4E0D\u4F1A\u8FD0\u884C\u3002</p><p>\u8FD9\u5BF9\u4E8E\u4EA4\u4E92\u5F0F\u5DE5\u5177\u7279\u522B\u6709\u7528\uFF0C\u53EF\u4EE5\u6709\u81EA\u5DF1\u7684\u72B6\u6001\uFF0C\u5728\u8FD0\u884C\u65F6\u6309\u952E\u5207\u6362\u9009\u9879\u7B49\u7B49\u3002</p><p>Grab\u3001Rotate\u3001Scale \u548C Fly-Mode \u90FD\u662F\u6A21\u6001\u8FD0\u7B97\u7B26\u7684\u793A\u4F8B\u3002</p><p><code>Operator.invoke</code>\u5148\u8FD4\u56DE<code>{&#39;RUNNING_MODAL&#39;}</code>\u6765\u521D\u59CB\u5316\u6A21\u6001\u5FAA\u73AF\u3002</p><p>\u901A\u77E5<code>__init__()</code>\u5E76\u88AB<code>__del__()</code>\u7533\u660E\u3002\u5BF9\u4E8E\u5176\u4ED6\u64CD\u4F5C\u9879\u7C7B\u578B\u6CA1\u6709\u7528\uFF0C\u4F46\u5BF9\u4E8E\u6A21\u6001\u64CD\u4F5C\u9879\uFF0C\u5B83\u4EEC\u5C06\u5728<code>Operator.invoke</code>\u4E4B\u524D\u548C\u64CD\u4F5C\u9879\u5B8C\u6210\u4E4B\u540E\u8C03\u7528\u3002</p><p>\u793A\u4F8B\uFF1A\u68C0\u6D4B\u9F20\u6807\u79FB\u52A8\uFF0C\u5E76\u5E94\u7528\u7ED9\u7269\u4F53</p><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code><span class="token keyword">import</span> bpy


<span class="token keyword">class</span> <span class="token class-name">ModalOperator</span><span class="token punctuation">(</span>bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>Operator<span class="token punctuation">)</span><span class="token punctuation">:</span>
    <span class="token triple-quoted-string string">&#39;&#39;&#39;\u68C0\u6D4B\u9F20\u6807\u79FB\u52A8\uFF0C\u5E76\u5E94\u7528\u7ED9\u7269\u4F53&#39;&#39;&#39;</span>
    bl_idname <span class="token operator">=</span> <span class="token string">&quot;object.modal_operator&quot;</span>
    bl_label <span class="token operator">=</span> <span class="token string">&quot;\u7B80\u5355\u6A21\u6001\u64CD\u4F5C\u9879&quot;</span>

    <span class="token keyword">def</span> <span class="token function">__init__</span><span class="token punctuation">(</span>self<span class="token punctuation">)</span><span class="token punctuation">:</span>
        <span class="token keyword">print</span><span class="token punctuation">(</span><span class="token string">&quot;\u5F00\u59CB&quot;</span><span class="token punctuation">)</span>

    <span class="token keyword">def</span> <span class="token function">__del__</span><span class="token punctuation">(</span>self<span class="token punctuation">)</span><span class="token punctuation">:</span>
        <span class="token keyword">print</span><span class="token punctuation">(</span><span class="token string">&quot;\u7ED3\u675F&quot;</span><span class="token punctuation">)</span>

    <span class="token keyword">def</span> <span class="token function">execute</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
        context<span class="token punctuation">.</span><span class="token builtin">object</span><span class="token punctuation">.</span>location<span class="token punctuation">.</span>x <span class="token operator">=</span> self<span class="token punctuation">.</span>value <span class="token operator">/</span> <span class="token number">100.0</span>
        <span class="token keyword">return</span> <span class="token punctuation">{</span><span class="token string">&#39;FINISHED&#39;</span><span class="token punctuation">}</span>

    <span class="token keyword">def</span> <span class="token function">modal</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">,</span> event<span class="token punctuation">)</span><span class="token punctuation">:</span>
        <span class="token keyword">if</span> event<span class="token punctuation">.</span><span class="token builtin">type</span> <span class="token operator">==</span> <span class="token string">&#39;MOUSEMOVE&#39;</span><span class="token punctuation">:</span>  <span class="token comment"># \u9F20\u6807\u79FB\u52A8\uFF0C\u6267\u884Cexcute</span>
            self<span class="token punctuation">.</span>value <span class="token operator">=</span> event<span class="token punctuation">.</span>mouse_x
            self<span class="token punctuation">.</span>execute<span class="token punctuation">(</span>context<span class="token punctuation">)</span>
        <span class="token keyword">elif</span> event<span class="token punctuation">.</span><span class="token builtin">type</span> <span class="token operator">==</span> <span class="token string">&#39;LEFTMOUSE&#39;</span><span class="token punctuation">:</span>  <span class="token comment"># \u9F20\u6807\u5DE6\u952E\uFF0C\u786E\u8BA4\u4F4D\u7F6E\uFF0C\u5E76\u7ED3\u675F</span>
            <span class="token keyword">return</span> <span class="token punctuation">{</span><span class="token string">&#39;FINISHED&#39;</span><span class="token punctuation">}</span>
        <span class="token keyword">elif</span> event<span class="token punctuation">.</span><span class="token builtin">type</span> <span class="token keyword">in</span> <span class="token punctuation">{</span><span class="token string">&#39;RIGHTMOUSE&#39;</span><span class="token punctuation">,</span> <span class="token string">&#39;ESC&#39;</span><span class="token punctuation">}</span><span class="token punctuation">:</span>   <span class="token comment"># \u9F20\u6807\u53F3\u952E\uFF0C\u4F4D\u7F6E\u8FD8\u539F\uFF0C\u5E76\u7ED3\u675F</span>
            context<span class="token punctuation">.</span><span class="token builtin">object</span><span class="token punctuation">.</span>location<span class="token punctuation">.</span>x <span class="token operator">=</span> self<span class="token punctuation">.</span>init_loc_x
            <span class="token keyword">return</span> <span class="token punctuation">{</span><span class="token string">&#39;CANCELLED&#39;</span><span class="token punctuation">}</span>

        <span class="token keyword">return</span> <span class="token punctuation">{</span><span class="token string">&#39;RUNNING_MODAL&#39;</span><span class="token punctuation">}</span>

    <span class="token keyword">def</span> <span class="token function">invoke</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">,</span> event<span class="token punctuation">)</span><span class="token punctuation">:</span>
        self<span class="token punctuation">.</span>init_loc_x <span class="token operator">=</span> context<span class="token punctuation">.</span><span class="token builtin">object</span><span class="token punctuation">.</span>location<span class="token punctuation">.</span>x
        self<span class="token punctuation">.</span>value <span class="token operator">=</span> event<span class="token punctuation">.</span>mouse_x
        self<span class="token punctuation">.</span>execute<span class="token punctuation">(</span>context<span class="token punctuation">)</span>

        context<span class="token punctuation">.</span>window_manager<span class="token punctuation">.</span>modal_handler_add<span class="token punctuation">(</span>self<span class="token punctuation">)</span>
        <span class="token keyword">return</span> <span class="token punctuation">{</span><span class="token string">&#39;RUNNING_MODAL&#39;</span><span class="token punctuation">}</span>


<span class="token keyword">def</span> <span class="token function">menu_func</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
    self<span class="token punctuation">.</span>layout<span class="token punctuation">.</span>operator<span class="token punctuation">(</span>ModalOperator<span class="token punctuation">.</span>bl_idname<span class="token punctuation">,</span> text<span class="token operator">=</span><span class="token string">&quot;Modal Operator&quot;</span><span class="token punctuation">)</span>

bpy<span class="token punctuation">.</span>utils<span class="token punctuation">.</span>register_class<span class="token punctuation">(</span>ModalOperator<span class="token punctuation">)</span>
bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>VIEW3D_MT_object<span class="token punctuation">.</span>append<span class="token punctuation">(</span>menu_func<span class="token punctuation">)</span>

<span class="token comment"># test</span>
bpy<span class="token punctuation">.</span>ops<span class="token punctuation">.</span><span class="token builtin">object</span><span class="token punctuation">.</span>modal_operator<span class="token punctuation">(</span><span class="token string">&#39;INVOKE_DEFAULT&#39;</span><span class="token punctuation">)</span>

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="\u679A\u4E3E\u641C\u7D22\u5F39\u51FA\u7A97\u53E3-enum" tabindex="-1"><a class="header-anchor" href="#\u679A\u4E3E\u641C\u7D22\u5F39\u51FA\u7A97\u53E3-enum" aria-hidden="true">#</a> \u679A\u4E3E\u641C\u7D22\u5F39\u51FA\u7A97\u53E3 Enum</h3><p>\u4F7F\u7528<code>bpy.types.Operator.invoke_search_popup</code>\uFF0C\u53EF\u4EE5\u63D0\u793A\u7528\u6237\u4ECE\u641C\u7D22\u5B57\u6BB5\u4E2D\u9009\u62E9\u4E00\u4E2A\u9879\u76EE</p><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code><span class="token keyword">import</span> bpy
<span class="token keyword">from</span> bpy<span class="token punctuation">.</span>props <span class="token keyword">import</span> EnumProperty


<span class="token keyword">class</span> <span class="token class-name">SearchEnumOperator</span><span class="token punctuation">(</span>bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>Operator<span class="token punctuation">)</span><span class="token punctuation">:</span>
    bl_idname <span class="token operator">=</span> <span class="token string">&quot;object.search_enum_operator&quot;</span>
    bl_label <span class="token operator">=</span> <span class="token string">&quot;Search Enum Operator&quot;</span>
    bl_property <span class="token operator">=</span> <span class="token string">&quot;my_search&quot;</span>

    <span class="token comment"># \u679A\u4E3E\u5C5E\u6027</span>
    my_search<span class="token punctuation">:</span> EnumProperty<span class="token punctuation">(</span>
        name<span class="token operator">=</span><span class="token string">&quot;My Search&quot;</span><span class="token punctuation">,</span>
        items<span class="token operator">=</span><span class="token punctuation">(</span>
            <span class="token punctuation">(</span><span class="token string">&#39;FOO&#39;</span><span class="token punctuation">,</span> <span class="token string">&quot;Foo&quot;</span><span class="token punctuation">,</span> <span class="token string">&quot;&quot;</span><span class="token punctuation">)</span><span class="token punctuation">,</span>
            <span class="token punctuation">(</span><span class="token string">&#39;BAR&#39;</span><span class="token punctuation">,</span> <span class="token string">&quot;Bar&quot;</span><span class="token punctuation">,</span> <span class="token string">&quot;&quot;</span><span class="token punctuation">)</span><span class="token punctuation">,</span>
            <span class="token punctuation">(</span><span class="token string">&#39;BAZ&#39;</span><span class="token punctuation">,</span> <span class="token string">&quot;Baz&quot;</span><span class="token punctuation">,</span> <span class="token string">&quot;&quot;</span><span class="token punctuation">)</span><span class="token punctuation">,</span>
        <span class="token punctuation">)</span><span class="token punctuation">,</span>
    <span class="token punctuation">)</span>

    <span class="token keyword">def</span> <span class="token function">execute</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
        self<span class="token punctuation">.</span>report<span class="token punctuation">(</span><span class="token punctuation">{</span><span class="token string">&#39;INFO&#39;</span><span class="token punctuation">}</span><span class="token punctuation">,</span> <span class="token string">&quot;\u5DF2\u9009\u62E9:&quot;</span> <span class="token operator">+</span> self<span class="token punctuation">.</span>my_search<span class="token punctuation">)</span>
        <span class="token keyword">return</span> <span class="token punctuation">{</span><span class="token string">&#39;FINISHED&#39;</span><span class="token punctuation">}</span>

    <span class="token keyword">def</span> <span class="token function">invoke</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">,</span> event<span class="token punctuation">)</span><span class="token punctuation">:</span>
        context<span class="token punctuation">.</span>window_manager<span class="token punctuation">.</span>invoke_search_popup<span class="token punctuation">(</span>self<span class="token punctuation">)</span>
        <span class="token keyword">return</span> <span class="token punctuation">{</span><span class="token string">&#39;RUNNING_MODAL&#39;</span><span class="token punctuation">}</span>

<span class="token keyword">def</span> <span class="token function">menu_func</span><span class="token punctuation">(</span>self<span class="token punctuation">,</span> context<span class="token punctuation">)</span><span class="token punctuation">:</span>
    self<span class="token punctuation">.</span>layout<span class="token punctuation">.</span>operator<span class="token punctuation">(</span>SearchEnumOperator<span class="token punctuation">.</span>bl_idname<span class="token punctuation">,</span> text<span class="token operator">=</span><span class="token string">&quot;Search Enum Operator&quot;</span><span class="token punctuation">)</span>

bpy<span class="token punctuation">.</span>utils<span class="token punctuation">.</span>register_class<span class="token punctuation">(</span>SearchEnumOperator<span class="token punctuation">)</span>
bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>VIEW3D_MT_object<span class="token punctuation">.</span>append<span class="token punctuation">(</span>menu_func<span class="token punctuation">)</span>

<span class="token comment"># test</span>
bpy<span class="token punctuation">.</span>ops<span class="token punctuation">.</span><span class="token builtin">object</span><span class="token punctuation">.</span>search_enum_operator<span class="token punctuation">(</span><span class="token string">&#39;INVOKE_DEFAULT&#39;</span><span class="token punctuation">)</span>

</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>base class \u2014 bpy_struct</p><p>classbpy.types.Operator(bpy_struct)</p><p>\u8BF4\u660E\uFF1AStorage of an operator being executed, or registered after execution</p><h3 id="bl-cursor-pending" tabindex="-1"><a class="header-anchor" href="#bl-cursor-pending" aria-hidden="true">#</a> bl_cursor_pending</h3><p>\u8BF4\u660E\uFF1A\u7528\u6237\u7B49\u5F85\u65F6\u7684\u9F20\u6807\u72B6\u6001\uFF08\u5F53 bl_options \u8BBE\u7F6E\u4E86 DEPENDS_ON_CURSOR \u65F6\uFF09\u3002</p><p>\u7C7B\u578B\uFF1A\u9ED8\u8BA4\u4E3A &quot;DEFAULT &quot;\u3002</p><ul><li>DEFAULT</li><li>NONE</li><li>WAIT</li><li>CROSSHAIR</li><li>MOVE_X</li><li>MOVE_Y</li><li>KNIFE</li><li>TEXT</li><li>PAINT_BRUSH</li><li>PAINT_CROSS</li><li>DOT</li><li>ERASER</li><li>HAND</li><li>SCROLL_X</li><li>SCROLL_Y</li><li>SCROLL_XY</li><li>EYEDROPPER</li><li>PICK_AREA</li><li>STOP</li><li>COPY</li><li>CROSS</li><li>MUTE</li><li>ZOOM_IN</li><li>ZOOM_OUT</li></ul><h3 id="bl-description" tabindex="-1"><a class="header-anchor" href="#bl-description" aria-hidden="true">#</a> bl_description</h3><p><img src="https://cdn.yuelili.com/20220113134937.png" alt=""></p><p>\u8BF4\u660E\uFF1A\u63CF\u8FF0\uFF0C\u6216\u8005\u67D0\u4E9B\u533A\u57DF\u7684\u63D0\u793A\u4FE1\u606F\uFF0C\u6BD4\u5982\u63A7\u5236\u53F0\u6309 tab \u8865\u5168\u7684\u65F6\u5019</p><p>\u7C7B\u578B\uFF1A\u5B57\u7B26\u4E32\uFF0C\u9ED8\u8BA4\u4E3A&quot;&quot;</p><h3 id="bl-idname" tabindex="-1"><a class="header-anchor" href="#bl-idname" aria-hidden="true">#</a> bl_idname</h3><p><img src="https://cdn.yuelili.com/20220113132251.png" alt=""></p><p>\u8BF4\u660E\uFF1AID \u540D\u79F0\uFF0C\u52A0\u4E0A\u7C7B\u540D\uFF0C\u53EF\u4EE5\u5728\u5176\u4ED6\u533A\u57DF\u8C03\u7528\uFF08\u63A7\u5236\u53F0\u3001\u522B\u7684\u7C7B\u3001\u9762\u677F\u63D2\u5165\u4E4B\u7C7B\uFF09</p><p>\u7C7B\u578B\uFF1A\u5B57\u7B26\u4E32\uFF0C\u9ED8\u8BA4\u4E3A&quot;&quot;</p><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code>bl_idname <span class="token operator">=</span> <span class="token string">&quot;yll.my_operator&quot;</span> <span class="token operator">&gt;&gt;</span><span class="token operator">&gt;</span> bpy<span class="token punctuation">.</span>ops<span class="token punctuation">.</span>yll<span class="token punctuation">.</span>my_operator
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h3 id="bl-label" tabindex="-1"><a class="header-anchor" href="#bl-label" aria-hidden="true">#</a> bl_label</h3><p><img src="https://cdn.yuelili.com/20220113152918.png" alt=""></p><p>\u8BF4\u660E\uFF1A\u663E\u793A\u540D\u79F0\uFF0C\u641C\u7D22\u7684\u65F6\u5019\u5C31\u80FD\u770B\u5230</p><p>\u7C7B\u578B\uFF1A\u5B57\u7B26\u4E32\uFF0C\u9ED8\u8BA4\u4E3A&quot;&quot;</p><h3 id="bl-options" tabindex="-1"><a class="header-anchor" href="#bl-options" aria-hidden="true">#</a> bl_options</h3><p>\u8BF4\u660E\uFF1A\u64CD\u4F5C\u9879\u7684\u8BBE\u7F6E</p><p>\u7C7B\u578B\uFF1A\u9ED8\u8BA4\u4E3A{&quot;REGISTER&quot;}\u3002</p><ul><li>REGISTER\uFF1A\u6CE8\u518C\u3002\u5728\u4FE1\u606F\u7A97\u53E3\u4E2D\u663E\u793A\uFF0C\u652F\u6301\u91CD\u505A\u5DE5\u5177\u6761\u9762\u677F\u3002</li><li>UNDO\uFF1A\u64A4\u9500\u3002\u63A8\u9001\u4E00\u4E2A\u64A4\u9500\u4E8B\u4EF6\uFF08\u64CD\u4F5C\u9879\u91CD\u505A\u9700\u8981\uFF09\u3002</li><li>UNDO_GROUPED\uFF1A\u5206\u7EC4\u64A4\u9500\u3002\u4E3A\u8BE5\u64CD\u4F5C\u9879\u7684\u91CD\u590D\u5B9E\u4F8B\u63A8\u9001\u4E00\u4E2A\u64A4\u9500\u4E8B\u4EF6\u3002</li><li>BLOCKING\uFF1A\u963B\u6B62\u3002\u963B\u6B62\u5176\u4ED6\u4E1C\u897F\u4F7F\u7528\u5149\u6807\u3002</li><li>MACRO\uFF1A\u5B8F\u3002\u7528\u6765\u68C0\u67E5\u4E00\u4E2A\u64CD\u4F5C\u9879\u662F\u5426\u662F\u5B8F\u3002</li><li>GRAB_CURSOR Grab Pointer\uFF1A\u7528\u6765\u4F7F\u64CD\u4F5C\u9879\u6293\u53D6\u9F20\u6807\u7126\u70B9\uFF0C\u5F53\u542F\u7528\u8FDE\u7EED\u6293\u53D6\u65F6\u542F\u7528\u5305\u88C5\u3002</li><li>GRAB_CURSOR_X Grab Pointer X\uFF1A\u6293\u53D6\uFF0C\u53EA\u5BF9 X \u8F74\u8FDB\u884C\u626D\u66F2\u3002</li><li>GRAB_CURSOR_Y Grab Pointer Y\uFF1A\u6293\u53D6\uFF0C\u53EA\u5BF9 Y \u8F74\u8FDB\u884C\u626D\u66F2\u3002</li><li>DEPENDS_ON_CURSOR Depends on Cursor\uFF1A\u3002\u4F7F\u7528\u521D\u59CB\u5149\u6807\u4F4D\u7F6E\uFF0C\u5F53\u4ECE\u83DC\u5355\u6216\u6309\u94AE\u8FD0\u884C\u65F6\uFF0C\u5728\u5F00\u59CB\u64CD\u4F5C\u524D\u4F1A\u63D0\u793A\u7528\u6237\u653E\u7F6E\u5149\u6807\u3002</li><li>PRESET\uFF1A\u9884\u8BBE\u3002\u663E\u793A\u5177\u6709\u64CD\u4F5C\u9879\u8BBE\u7F6E\u7684\u9884\u8BBE\u6309\u94AE\u3002</li><li>INTERNAL\uFF1A\u5185\u90E8\u3002F3 \u641C\u7D22\u4E2D\u79FB\u9664\u672C\u64CD\u4F5C\u9879\u3002</li></ul><h3 id="bl-translation-context" tabindex="-1"><a class="header-anchor" href="#bl-translation-context" aria-hidden="true">#</a> bl_translation_context</h3><p>\u8BF4\u660E\uFF1A</p><p>\u7C7B\u578B\uFF1A\u5B57\u7B26\u4E32\uFF0C\u9ED8\u8BA4\u4E3A\u201COperator\u201D, (never None)</p><h3 id="bl-undo-group" tabindex="-1"><a class="header-anchor" href="#bl-undo-group" aria-hidden="true">#</a> bl_undo_group</h3><p>\u8BF4\u660E\uFF1A</p><p>\u7C7B\u578B\uFF1A\u5B57\u7B26\u4E32\uFF0C\u9ED8\u8BA4\u4E3A&quot;&quot;</p><h3 id="has-reports" tabindex="-1"><a class="header-anchor" href="#has-reports" aria-hidden="true">#</a> has_reports</h3><p>\u8BF4\u660E\uFF1A\u64CD\u4F5C\u9879\u6709\u4E0A\u6B21\u6267\u884C\u7684\u62A5\u544A\uFF08\u8B66\u544A\u548C\u9519\u8BEF\uFF09\u3002</p><p>\u7C7B\u578B\uFF1Aboolean, default False, (readonly)</p><h3 id="layout" tabindex="-1"><a class="header-anchor" href="#layout" aria-hidden="true">#</a> layout</h3><p>\u8BF4\u660E\uFF1A\u5E03\u5C40 UI</p><p>\u7C7B\u578B\uFF1AUILayout, (\u53EA\u8BFB)</p><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code>layout <span class="token operator">=</span> self<span class="token punctuation">.</span>layout balabala \u521B\u5EFA\u5E03\u5C40
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><h3 id="macros" tabindex="-1"><a class="header-anchor" href="#macros" aria-hidden="true">#</a> macros</h3><p>\u8BF4\u660E\uFF1A</p><p>\u7C7B\u578B\uFF1Abpy_prop_collection of Macro, (\u53EA\u8BFB)</p><h3 id="name" tabindex="-1"><a class="header-anchor" href="#name" aria-hidden="true">#</a> name</h3><p>\u8BF4\u660E\uFF1A\u540D\u79F0</p><p>\u7C7B\u578B\uFF1A\u5B57\u7B26\u4E32\uFF0C\u9ED8\u8BA4\u4E3A&quot;&quot;, (\u53EA\u8BFB\uFF0C\u4E0D\u4E3A None)</p><h3 id="options" tabindex="-1"><a class="header-anchor" href="#options" aria-hidden="true">#</a> options</h3><p>\u8BF4\u660E\uFF1A\u8FD0\u884C\u65F6\u7684\u9009\u9879</p><p>\u7C7B\u578B\uFF1AOperatorOptions, (\u53EA\u8BFB\uFF0C\u4E0D\u4E3A None)</p><h3 id="properties" tabindex="-1"><a class="header-anchor" href="#properties" aria-hidden="true">#</a> properties</h3><p>\u8BF4\u660E\uFF1A\u5C5E\u6027</p><p>\u7C7B\u578B\uFF1AOperatorProperties, (\u53EA\u8BFB\uFF0C\u4E0D\u4E3A None)</p><h3 id="bl-property" tabindex="-1"><a class="header-anchor" href="#bl-property" aria-hidden="true">#</a> bl_property</h3><p>\u8BF4\u660E\uFF1A\u7528\u4F5C\u6B64\u64CD\u4F5C\u9879\u4E3B\u8981\u5C5E\u6027\u7684\u5C5E\u6027\u540D\u79F0\u3002\u76EE\u524D\u53EA\u7528\u4E8E\u5728\u5C06\u64CD\u4F5C\u9879\u6269\u5C55\u5230\u83DC\u5355\u65F6\u9009\u62E9\u9ED8\u8BA4\u5C5E\u6027\u3002</p><p>\u7C7B\u578B\uFF1A string</p><h3 id="report-type-message" tabindex="-1"><a class="header-anchor" href="#report-type-message" aria-hidden="true">#</a> report(type, message)</h3><p>\u5168\u540D\uFF1Areport(type, message)</p><p>\u8BF4\u660E\uFF1Areport</p><p>\u53C2\u6570\uFF1A</p><ul><li>type\uFF1A\u7C7B\u578B\u3002{\u7C7B\u578B\u5217\u8868\u4E4B\u4E00}\uFF0C\u6BD4\u5982 {&#39;INFO&#39;}</li><li>message\uFF1A\u8981\u4F20\u9012\u7684\u4FE1\u606F\uFF0C\u5B57\u7B26\u4E32</li></ul><p>\u7C7B\u578B\u5217\u8868\uFF1A</p><ul><li><p>DEBUG\uFF1A\u8C03\u8BD5</p></li><li><p>INFO\uFF1A\u4FE1\u606F</p></li><li><p>OPERATOR\uFF1A\u64CD\u4F5C\u9879</p></li><li><p>PROPERTY\uFF1A\u5C5E\u6027</p></li><li><p>WARNING\uFF1A\u8B66\u544A</p></li><li><p>ERROR\uFF1A\u9519\u8BEF</p></li><li><p>ERROR_INVALID_INPUT\uFF1A\u975E\u6CD5\u8F93\u5165</p></li><li><p>ERROR_INVALID_CONTEXT\uFF1A\u975E\u6CD5\u4E0A\u4E0B\u6587</p></li><li><p>ERROR_OUT_OF_MEMORY\uFF1A\u5185\u5B58\u4E0D\u8DB3</p><p>self.report({&#39;INFO&#39;}, &quot;hello&quot;)</p></li></ul><div class="language-text ext-text line-numbers-mode"><pre class="language-text"><code>

    ## is_repeat() #




    \u8BF4\u660E\uFF1Ais_repeat




    \u8FD4\u56DE\uFF1Aresult




    \u8FD4\u56DE\u7C7B\u578B\uFF1Aboolean




    ## classmethodpoll() #




    \u5168\u540D\uFF1Aclassmethodpoll(context)




    \u8BF4\u660E\uFF1A\u6D4B\u8BD5\u8BE5\u64CD\u4F5C\u9879\u662F\u5426\u53EF\u4EE5\u88AB\u8C03\u7528




    \u8FD4\u56DE\u7C7B\u578B\uFF1Aboolean




    ## execute() #




    \u5168\u540D\uFF1Aexecute(context)




    \u8BF4\u660E\uFF1A\u6267\u884C\u64CD\u4F5C\u9879




    \u53C2\u6570\uFF1Acontext\uFF0C\u4EE3\u8868\u8981\u5904\u7406\u7684\u5185\u5BB9\uFF0C\u4E0D\u662Fbpy.context\u5594




    \u8FD4\u56DE\uFF1Aresult\uFF0C\u8FD4\u56DE\u7C7B\u578B\u5217\u8868\u4E4B\u4E00\u3002\u6BD4\u5982\uFF1A{&quot;FINISHED&quot;}




    \u8FD4\u56DE\u7C7B\u578B\u5217\u8868\uFF1A






      * RUNNING_MODAL\uFF1A\u4FDD\u6301\u8FD0\u884C\u6A21\u5F0F\uFF0C\u64CD\u4F5C\u9879\u4E0Eblender\u4E00\u8D77\u8FD0\u884C\u3002


      * CANCELLED\uFF1A\u53D6\u6D88\u3002 \u64CD\u4F5C\u9879\u4E0D\u505A\u4EFB\u4F55\u4E8B\u60C5\u9000\u51FA\uFF0C\u6240\u4EE5\u4E0D\u5E94\u8BE5\u63A8\u9001\u64A4\u9500\u6761\u76EE\u3002


      * FINISHED\uFF1A\u5B8C\u6210\u3002\u64CD\u4F5C\u9879\u5728\u5B8C\u6210\u5176\u52A8\u4F5C\u540E\u9000\u51FA\u3002


      * PASS_THROUGH\uFF1A\u8DF3\u8FC7\u3002\u4E0D\u505A\u4EFB\u4F55\u4E8B\u60C5\uFF0C\u5C06\u4E8B\u4EF6\u4F20\u9012\u4E0B\u53BB\u3002


      * INTERFACE\uFF1A\u754C\u9762\u3002 \u5904\u7406\u4F46\u4E0D\u6267\u884C\uFF08\u5F39\u51FA\u5F0F\u83DC\u5355\uFF09\u3002





    ## check() #




    \u5168\u540D\uFF1Acheck(context)




    \u8BF4\u660E\uFF1A\u68C0\u67E5\u64CD\u4F5C\u9879\u7684\u8BBE\u7F6E\uFF0C\u8FD4\u56DETrue\u8BF4\u660E\u91CD\u7ED8\u3002




    \u8FD4\u56DE\uFF1Aresult




    \u8FD4\u56DE\u7C7B\u578B\uFF1Aboolean




    ## invoke() #




    \u5168\u540D\uFF1Ainvoke(context, event)




    \u8BF4\u660E\uFF1A\u8C03\u7528\u64CD\u4F5C\u9879




    \u53C2\u6570\uFF1A






      * context\uFF1A\u4EE3\u8868\u8981\u5904\u7406\u7684\u5185\u5BB9


      * event\uFF1A\u4F20\u9012\u8FDB\u6765\u7684\u4E8B\u4EF6\u3002\u6BD4\u5982\u9F20\u6807\u79FB\u52A8\uFF0C\u6309\u952E\u4FE1\u606F\u4E4B\u7C7B





    \u8FD4\u56DE\uFF1Aresult\uFF0C\u8FD4\u56DE\u7C7B\u578B\u5217\u8868\u4E4B\u4E00\u3002\u6BD4\u5982\uFF1A{&quot;FINISHED&quot;}




    \u8FD4\u56DE\u7C7B\u578B\u5217\u8868\uFF1A






      * RUNNING_MODAL\uFF1A\u4FDD\u6301\u8FD0\u884C\u6A21\u5F0F\uFF0C\u64CD\u4F5C\u9879\u4E0Eblender\u4E00\u8D77\u8FD0\u884C\u3002


      * CANCELLED\uFF1A\u53D6\u6D88\u3002 \u64CD\u4F5C\u9879\u4E0D\u505A\u4EFB\u4F55\u4E8B\u60C5\u9000\u51FA\uFF0C\u6240\u4EE5\u4E0D\u5E94\u8BE5\u63A8\u9001\u64A4\u9500\u6761\u76EE\u3002


      * FINISHED\uFF1A\u5B8C\u6210\u3002\u64CD\u4F5C\u9879\u5728\u5B8C\u6210\u5176\u52A8\u4F5C\u540E\u9000\u51FA\u3002


      * PASS_THROUGH\uFF1A\u8DF3\u8FC7\u3002\u4E0D\u505A\u4EFB\u4F55\u4E8B\u60C5\uFF0C\u5C06\u4E8B\u4EF6\u4F20\u9012\u4E0B\u53BB\u3002


      * INTERFACE\uFF1A\u754C\u9762\u3002 \u5904\u7406\u4F46\u4E0D\u6267\u884C\uFF08\u5F39\u51FA\u5F0F\u83DC\u5355\uFF09\u3002





    ## modal() #




    \u5168\u540D\uFF1Amodal(context, event)




    \u8BF4\u660E\uFF1A\u6A21\u6001\u64CD\u4F5C\u9879\u51FD\u6570




    \u53C2\u6570\uFF1A






      * context\uFF1A\u4EE3\u8868\u8981\u5904\u7406\u7684\u5185\u5BB9


      * event\uFF1A\u4F20\u9012\u8FDB\u6765\u7684\u4E8B\u4EF6\u3002\u6BD4\u5982\u9F20\u6807\u79FB\u52A8\uFF0C\u6309\u952E\u4FE1\u606F\u4E4B\u7C7B





    \u8FD4\u56DE\uFF1Aresult\uFF0C\u8FD4\u56DE\u7C7B\u578B\u5217\u8868\u4E4B\u4E00\u3002\u6BD4\u5982\uFF1A{&quot;FINISHED&quot;}




    \u8FD4\u56DE\u7C7B\u578B\u5217\u8868\uFF1A






      * RUNNING_MODAL\uFF1A\u4FDD\u6301\u8FD0\u884C\u6A21\u5F0F\uFF0C\u64CD\u4F5C\u9879\u4E0Eblender\u4E00\u8D77\u8FD0\u884C\u3002


      * CANCELLED\uFF1A\u53D6\u6D88\u3002 \u64CD\u4F5C\u9879\u4E0D\u505A\u4EFB\u4F55\u4E8B\u60C5\u9000\u51FA\uFF0C\u6240\u4EE5\u4E0D\u5E94\u8BE5\u63A8\u9001\u64A4\u9500\u6761\u76EE\u3002


      * FINISHED\uFF1A\u5B8C\u6210\u3002\u64CD\u4F5C\u9879\u5728\u5B8C\u6210\u5176\u52A8\u4F5C\u540E\u9000\u51FA\u3002


      * PASS_THROUGH\uFF1A\u8DF3\u8FC7\u3002\u4E0D\u505A\u4EFB\u4F55\u4E8B\u60C5\uFF0C\u5C06\u4E8B\u4EF6\u4F20\u9012\u4E0B\u53BB\u3002


      * INTERFACE\uFF1A\u754C\u9762\u3002 \u5904\u7406\u4F46\u4E0D\u6267\u884C\uFF08\u5F39\u51FA\u5F0F\u83DC\u5355\uFF09\u3002





    ## draw() #




    \u5168\u540D\uFF1Adraw(context)




    \u53C2\u6570\uFF1Acontext\uFF0C\u4EE3\u8868\u8981\u5904\u7406\u7684\u5185\u5BB9




    \u8BF4\u660E\uFF1A\u7ED8\u5236\u64CD\u4F5C\u9879\u3002draw \u662F\u5B9E\u65F6\u5237\u65B0




    ## cancel() #




    \u5168\u540D\uFF1Acancel(context)




    \u8BF4\u660E\uFF1A\u5F53\u64CD\u4F5C\u9879\u53D6\u6D88\uFF0C\u6267\u884C\u7684\u5185\u5BB9




    ## classmethod description() #




    \u5168\u540D\uFF1Aclassmethoddescription(context, properties)




    \u8BF4\u660E\uFF1A\u8BA1\u7B97\u4E00\u4E2A\u53D6\u51B3\u4E8E\u53C2\u6570\u7684\u63CF\u8FF0\u5B57\u7B26\u4E32




    \u8FD4\u56DE\uFF1Aresult




    \u8FD4\u56DE\u7C7B\u578B\uFF1Astring




    ## as_keywords() #




    \u5168\u540D\uFF1Aas_keywords(*, ignore=())




    \u8BF4\u660E\uFF1A\u4EE5\u5B57\u5178\u7684\u5F62\u5F0F\u8FD4\u56DE\u5C5E\u6027\u7684\u526F\u672C




    ## classmethod bl_rna_get_subclass() #




    \u5168\u540D\uFF1Aclassmethodbl_rna_get_subclass(id, default=None)




    \u8BF4\u660E\uFF1A




    \u53C2\u6570\uFF1Aid (string) \u2013 The RNA type identifier.




    \u8FD4\u56DE\uFF1ARNA\u7C7B\u578B\uFF0C\u5982\u679C\u6CA1\u6709\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




    \u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass




    ## classmethod bl_rna_get_subclass_py() #




    \u5168\u540D\uFF1Aclassmethodbl_rna_get_subclass_py(id, default=None)




    \u8BF4\u660E\uFF1A\u53C2\u6570\uFF1Aid (string) \u2013 The RNA type identifier.




    \u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u5982\u679C\u6CA1\u6709\u627E\u5230\uFF0C\u5219\u4E3A\u9ED8\u8BA4\u3002




    \u8FD4\u56DE\u7C7B\u578B\uFF1Atype




    ## poll_message_set() #




    \u5168\u540D\uFF1Apoll_message_set(message, *args)




    \u8BF4\u660E\uFF1ASet the message to show in the tool-tip when poll fails.




    \u5F53\u6D88\u606F\u662F\u53EF\u8C03\u7528\u7684\uFF0C\u989D\u5916\u7684\u7528\u6237\u5B9A\u4E49\u7684\u4F4D\u7F6E\u53C2\u6570\u88AB\u4F20\u9012\u7ED9\u6D88\u606F\u51FD\u6570\u3002




    \u53C2\u6570\uFF1Amessage\uFF0C(string or a callable that returns a string or None.) \u3002\u6D88\u606F\u6216\u4E00\u4E2A\u8FD4\u56DE\u6D88\u606F\u7684\u51FD\u6570\u3002




     




     





</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div>`,110);function y(_,h){const a=c("ExternalLinkIcon");return p(),l("div",null,[u,n("p",null,[n("a",d,[s("bpy.ops"),e(a)]),s("\uFF1Aops \u7C7B")]),n("p",null,[n("a",r,[s("\u5176\u4ED6\u64CD\u4F5C\u9879\u5B50\u7C7B\u603B\u89C8"),e(a)]),s("\uFF1A\u4E00\u4E9B\u5176\u4ED6\u7684\u64CD\u4F5C\u9879\u7C7B")]),n("p",null,[n("a",v,[s("bpy.types.Operator"),e(a)]),s("\uFF1A\u64CD\u4F5C\u9879\u7684\u53C2\u6570\uFF08\u867D\u7136\u6709\u70B9\u50ED\u8D8A\uFF0C\u4F46\u6211\u89C9\u5F97\u653E\u8FD9\u91CC\u6BD4\u8F83\u597D\uFF09")]),m,n("p",null,[s("\u53E6\u89C1"),n("a",k,[s("bpy.types.Operator"),e(a)])]),b])}const x=t(o,[["render",y],["__file","\u64CD\u4F5C\u9879(bpy.ops).html.vue"]]);export{x as default};
