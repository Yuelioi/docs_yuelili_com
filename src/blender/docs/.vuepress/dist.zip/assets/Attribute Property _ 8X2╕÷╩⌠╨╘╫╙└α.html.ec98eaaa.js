import{_ as r}from"./_plugin-vue_export-helper.cdc0426e.js";import{o as t,c as l,a as e,b as n,e as s,f as a,r as d}from"./app.d29ede9e.js";const u={},c=e("h2",{id:"description",tabindex:"-1"},[e("a",{class:"header-anchor",href:"#description","aria-hidden":"true"},"#"),n(" Description")],-1),p=e("p",null,[e("strong",null,"Attribute \u5C5E\u6027\uFF08\u51E0\u4F55\u5C5E\u6027\uFF09")],-1),b={href:"https://docs.blender.org/api/master/bpy.types.Attribute.html",target:"_blank",rel:"noopener noreferrer"},o={href:"https://docs.blender.org/api/master/bpy.types.AttributeGroup.html",target:"_blank",rel:"noopener noreferrer"},v=e("p",null,[e("strong",null,"Property \u5C5E\u6027\uFF08RNA \u5C5E\u6027\uFF09")],-1),h={href:"https://docs.blender.org/api/master/bpy.types.Property.html",target:"_blank",rel:"noopener noreferrer"},m={href:"https://docs.blender.org/api/master/bpy.types.PropertyGroup.html",target:"_blank",rel:"noopener noreferrer"},y={href:"https://docs.blender.org/api/master/bpy.types.PropertyGroupItem.html",target:"_blank",rel:"noopener noreferrer"},_=e("p",null,[e("strong",null,"\u57FA\u672C\u5C5E\u6027(Attribute)")],-1),f={href:"https://docs.blender.org/api/master/bpy.types.BoolAttribute.html#bpy.types.BoolAttribute",target:"_blank",rel:"noopener noreferrer"},g={href:"https://docs.blender.org/api/master/bpy.types.ByteColorAttribute.html#bpy.types.ByteColorAttribute",target:"_blank",rel:"noopener noreferrer"},A={href:"https://docs.blender.org/api/master/bpy.types.Float2Attribute.html#bpy.types.Float2Attribute",target:"_blank",rel:"noopener noreferrer"},N={href:"https://docs.blender.org/api/master/bpy.types.FloatAttribute.html#bpy.types.FloatAttribute",target:"_blank",rel:"noopener noreferrer"},x={href:"https://docs.blender.org/api/master/bpy.types.FloatColorAttribute.html#bpy.types.FloatColorAttribute",target:"_blank",rel:"noopener noreferrer"},R={href:"https://docs.blender.org/api/master/bpy.types.FloatVectorAttribute.html#bpy.types.FloatVectorAttribute",target:"_blank",rel:"noopener noreferrer"},P={href:"https://docs.blender.org/api/master/bpy.types.IntAttribute.html#bpy.types.IntAttribute",target:"_blank",rel:"noopener noreferrer"},T={href:"https://docs.blender.org/api/master/bpy.types.StringAttribute.html#bpy.types.StringAttribute",target:"_blank",rel:"noopener noreferrer"},E=e("p",null,[e("strong",null,"\u57FA\u672C\u5C5E\u6027(Property)")],-1),k={href:"https://docs.blender.org/api/master/bpy.types.BoolProperty.html",target:"_blank",rel:"noopener noreferrer"},F={href:"https://docs.blender.org/api/master/bpy.types.CollectionProperty.html",target:"_blank",rel:"noopener noreferrer"},S={href:"https://docs.blender.org/api/master/bpy.types.EnumProperty.html",target:"_blank",rel:"noopener noreferrer"},q={href:"https://docs.blender.org/api/master/bpy.types.FloatProperty.html",target:"_blank",rel:"noopener noreferrer"},I={href:"https://docs.blender.org/api/master/bpy.types.IntProperty.html",target:"_blank",rel:"noopener noreferrer"},O={href:"https://docs.blender.org/api/master/bpy.types.PointerProperty.html",target:"_blank",rel:"noopener noreferrer"},C={href:"https://docs.blender.org/api/master/bpy.types.StringProperty.html",target:"_blank",rel:"noopener noreferrer"},L={href:"https://docs.blender.org/api/master/bpy.types.Struct.html",target:"_blank",rel:"noopener noreferrer"},G={href:"https://docs.blender.org/api/master/bpy.types.EnumPropertyItem.html",target:"_blank",rel:"noopener noreferrer"},M=a('<p><strong>\u56FE\u793A\uFF1A</strong></p><p><img src="https://cdn.yuelili.com/20220112013129.png" alt=""></p><h2 id="attribute-bpy-struct" tabindex="-1"><a class="header-anchor" href="#attribute-bpy-struct" aria-hidden="true">#</a> Attribute(bpy_struct)</h2><p>\u51E0\u4F55\u5C5E\u6027</p><h3 id="data-type" tabindex="-1"><a class="header-anchor" href="#data-type" aria-hidden="true">#</a> data_type</h3><p>\u8BF4\u660E\uFF1A\u50A8\u5B58\u5728\u5C5E\u6027\u4E2D\u7684\u6570\u636E\u7C7B\u578B</p><ul><li>FLOAT\uFF0CFloat - \u6D6E\u70B9\u503C\u3002</li><li>INT\uFF0CInteger - 32 \u4F4D\u6574\u6570\u3002</li><li>FLOAT_VECTOR\uFF0CVector - \u5177\u6709\u6D6E\u70B9\u503C\u7684 3D \u5411\u91CF\u3002</li><li>FLOAT_COLOR\uFF0CColor - \u5177\u6709\u6D6E\u70B9\u503C\u7684 RGBA \u989C\u8272\u3002</li><li>BYTE_COLOR\uFF0CByte Color - \u5177\u6709 8 \u4F4D\u6570\u503C\u7684 RGBA \u989C\u8272\u3002</li><li>STRING\uFF0CString - \u6587\u672C\u5B57\u7B26\u4E32\u3002</li><li>BOOLEAN\uFF0CBoolean - \u771F\u6216\u5047\u3002</li><li>FLOAT2\uFF0C2D Vector - \u5177\u6709\u6D6E\u70B9\u503C\u7684 2D \u5411\u91CF\u3002</li></ul><p>\u7C7B\u578B\uFF1A\u4EE5\u4E0A\u4E4B\u4E00\uFF0C\u9ED8\u8BA4\u4E3A\u2018FLOAT\u2019, \u53EA\u8BFB</p><h3 id="domain" tabindex="-1"><a class="header-anchor" href="#domain" aria-hidden="true">#</a> domain</h3><p>\u8BF4\u660E\uFF1A\u5C5E\u6027\u4F5C\u7528\u8303\u56F4</p><p>POINT\uFF1APoint\uFF0C\u70B9\u7684\u5C5E\u6027</p><p>EDGE\uFF1AEdge\uFF0C\u7F51\u683C\u8FB9\u7F18\u7684\u5C5E\u6027</p><p>FACE\uFF1AFace\uFF0C\u7F51\u683C\u9762\u7684\u5C5E\u6027</p><p>CORNER\uFF1AFace Corner\uFF0C\u7F51\u683C\u9762\u89D2\u5C5E\u6027</p><p>CURVE\uFF1ASpline\uFF0Cspline \u5C5E\u6027</p><p>INSTANCE\uFF1AInstance\uFF0C\u5B9E\u4F8B\u5C5E\u6027</p><p>\u7C7B\u578B\uFF1A\u4EE5\u4E0A\u4E4B\u4E00\uFF0C\u9ED8\u8BA4\u4E3A\u2018POINT\u2019, \u53EA\u8BFB</p><h3 id="name" tabindex="-1"><a class="header-anchor" href="#name" aria-hidden="true">#</a> name</h3><p>\u8BF4\u660E\uFF1A\u5C5E\u6027\u540D\u79F0</p><p>\u7C7B\u578B\uFF1A\u5B57\u7B26\u4E32\uFF0C\u9ED8\u8BA4\u4E3A&quot;&quot;, \u4E0D\u4F1A\u4E3A None</p><h3 id="classmethod-bl-rna-get-subclass" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u2013 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u2013 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><h2 id="attributegroup-bpy-struct" tabindex="-1"><a class="header-anchor" href="#attributegroup-bpy-struct" aria-hidden="true">#</a> AttributeGroup(bpy_struct)</h2><p>Group of geometry attributes</p><h3 id="active" tabindex="-1"><a class="header-anchor" href="#active" aria-hidden="true">#</a> active</h3><p>\u8BF4\u660E\uFF1A\u6FC0\u6D3B\u5C5E\u6027</p><p>\u7C7B\u578B\uFF1AAttribute</p><h3 id="active-index" tabindex="-1"><a class="header-anchor" href="#active-index" aria-hidden="true">#</a> active_index</h3><p>\u8BF4\u660E\uFF1A</p><p>\u7C7B\u578B\uFF1Aint in [-inf, inf], default 0</p><h3 id="new" tabindex="-1"><a class="header-anchor" href="#new" aria-hidden="true">#</a> new()</h3><p>\u5168\u540D\uFF1Anew(name, type, domain)</p><p>\u8BF4\u660E\uFF1A\u6DFB\u52A0\u4E00\u4E2A\u5C5E\u6027</p><p>\u53C2\u6570\uFF1Aname (string, \u4E0D\u4F1A\u4E3A None) \u3002 \u5C5E\u6027\u540D</p><p>type\uFF1A\u5176\u4E2D\u4E4B\u4E00</p><ul><li>FLOAT\uFF0CFloat - \u6D6E\u70B9\u503C\u3002</li><li>INT\uFF0CInteger - 32 \u4F4D\u6574\u6570\u3002</li><li>FLOAT_VECTOR\uFF0CVector - \u5177\u6709\u6D6E\u70B9\u503C\u7684 3D \u5411\u91CF\u3002</li><li>FLOAT_COLOR\uFF0CColor - \u5177\u6709\u6D6E\u70B9\u503C\u7684 RGBA \u989C\u8272\u3002</li><li>BYTE_COLOR\uFF0CByte Color - \u5177\u6709 8 \u4F4D\u6570\u503C\u7684 RGBA \u989C\u8272\u3002</li><li>STRING\uFF0CString - \u6587\u672C\u5B57\u7B26\u4E32\u3002</li><li>BOOLEAN\uFF0CBoolean - \u771F\u6216\u5047\u3002</li><li>FLOAT2\uFF0C2D Vector - \u5177\u6709\u6D6E\u70B9\u503C\u7684 2D \u5411\u91CF\u3002</li></ul><p>domain</p><ul><li>Domain\uFF1A\u5C5E\u6027\u6240\u5B58\u50A8\u7684\u5143\u7D20\u7684\u7C7B\u578B\u3002</li><li>POINT\uFF1A\u70B9\u4E0A\u7684\u5C5E\u6027\u3002</li><li>EDGE\uFF1A\u7F51\u683C\u8FB9\u7F18\u7684\u5C5E\u6027\u3002</li><li>FACE\uFF1A\u7F51\u683C\u9762\u7684\u5C5E\u6027\u3002</li><li>CORNER\uFF1A\u7F51\u683C\u9762\u89D2\u7684\u5C5E\u6027\u3002</li><li>CURVE Spline\uFF1ACURVE Spline \u7684\u5C5E\u6027\u3002</li><li>INSTANCE\uFF1A\u5B9E\u4F8B\u7684\u5C5E\u6027\u3002</li></ul><p>\u8FD4\u56DE\uFF1A\u65B0\u7684\u51E0\u4F55\u5C5E\u6027</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1AAttribute</p><h3 id="remove" tabindex="-1"><a class="header-anchor" href="#remove" aria-hidden="true">#</a> remove()</h3><p>\u5168\u540D\uFF1Aremove(attribute)</p><p>\u8BF4\u660E\uFF1A\u79FB\u9664\u5C5E\u6027</p><p>\u53C2\u6570\uFF1Aattribute (Attribute, \u4E0D\u4F1A\u4E3A None) \u3002 Geometry Attribute</p><h3 id="classmethod-bl-rna-get-subclass-1" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-1" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py-1" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py-1" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><h2 id="property-bpy-struct" tabindex="-1"><a class="header-anchor" href="#property-bpy-struct" aria-hidden="true">#</a> Property(bpy_struct)</h2><p>\u57FA\u7C7B\uFF1A bpy_struct</p><p>\u5B50\u7C7B\uFF1ABoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty,PointerProperty, StringProperty</p><p>\u4ECB\u7ECD\uFF1ARNA \u5C5E\u6027\u5B9A\u4E49</p><h3 id="description-\u5C5E\u6027\u63CF\u8FF0" tabindex="-1"><a class="header-anchor" href="#description-\u5C5E\u6027\u63CF\u8FF0" aria-hidden="true">#</a> description \u5C5E\u6027\u63CF\u8FF0</h3><p>\u8BF4\u660E\uFF1A\u6B64\u5C5E\u6027\u7684\u5E2E\u52A9\u63CF\u8FF0</p><p>\u7C7B\u578B\uFF1A\u5B57\u7B26\u4E32\uFF0C\u9ED8\u8BA4\u4E3A&quot;&quot;\uFF0C\u53EA\u8BFB\uFF0C\u53EF\u9009</p><h3 id="icon-\u56FE\u6807" tabindex="-1"><a class="header-anchor" href="#icon-\u56FE\u6807" aria-hidden="true">#</a> icon \u56FE\u6807</h3><p>\u8BF4\u660E\uFF1A\u9879\u76EE\u56FE\u6807</p>',71),B={href:"https://www.yuelili.com/blender-development-use-blenders-own-icon/",target:"_blank",rel:"noopener noreferrer"},D=a(`<h3 id="identifier-\u6807\u8BC6\u7B26" tabindex="-1"><a class="header-anchor" href="#identifier-\u6807\u8BC6\u7B26" aria-hidden="true">#</a> identifier \u6807\u8BC6\u7B26</h3><p>\u8BF4\u660E\uFF1A\u5728\u4EE3\u7801\u548C\u811A\u672C\u4E2D\u4F7F\u7528\u7684\u552F\u4E00\u540D\u79F0</p><p>\u7C7B\u578B\uFF1A\u5B57\u7B26\u4E32\uFF0C\u9ED8\u8BA4\u4E3A&quot;&quot;\uFF0C\u53EA\u8BFB\uFF0C\u53EF\u9009</p><h3 id="is-animatable" tabindex="-1"><a class="header-anchor" href="#is-animatable" aria-hidden="true">#</a> is_animatable</h3><p>\u8BF4\u660E\uFF1AProperty is animatable through RNA</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="is-argument-optional" tabindex="-1"><a class="header-anchor" href="#is-argument-optional" aria-hidden="true">#</a> is_argument_optional</h3><p>\u8BF4\u660E\uFF1A\u5728\u5B9E\u73B0 RNA \u51FD\u6570\u7684 Python \u51FD\u6570\u4E2D\uFF0C\u5F53\u5C5E\u6027\u4E3A\u53EF\u9009\u65F6\u4E3A True\u3002</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="is-enum-flag" tabindex="-1"><a class="header-anchor" href="#is-enum-flag" aria-hidden="true">#</a> is_enum_flag</h3><p>\u8BF4\u660E\uFF1ATrue when multiple enums</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="is-hidden" tabindex="-1"><a class="header-anchor" href="#is-hidden" aria-hidden="true">#</a> is_hidden</h3><p>\u8BF4\u660E\uFF1A\u5F53\u5C5E\u6027\u9690\u85CF\u65F6\u4E3A True</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="is-library-editable" tabindex="-1"><a class="header-anchor" href="#is-library-editable" aria-hidden="true">#</a> is_library_editable</h3><p>\u8BF4\u660E\uFF1AProperty is editable from linked instances (changes not saved)</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="is-never-none" tabindex="-1"><a class="header-anchor" href="#is-never-none" aria-hidden="true">#</a> is_never_none</h3><p>\u8BF4\u660E\uFF1A\u5F53\u5C5E\u6027\u4E0D\u80FD\u8BBE\u7F6E\u4E3A None \u65F6\u4E3A True</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="is-output" tabindex="-1"><a class="header-anchor" href="#is-output" aria-hidden="true">#</a> is_output</h3><p>\u8BF4\u660E\uFF1ATrue when this property is an output value from an RNA function</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="is-overridable" tabindex="-1"><a class="header-anchor" href="#is-overridable" aria-hidden="true">#</a> is_overridable</h3><p>\u8BF4\u660E\uFF1AProperty is overridable through RNA</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="is-readonly" tabindex="-1"><a class="header-anchor" href="#is-readonly" aria-hidden="true">#</a> is_readonly</h3><p>\u8BF4\u660E\uFF1A\u5C5E\u6027\u53EF\u901A\u8FC7 RNA \u8FDB\u884C\u7F16\u8F91</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="is-registered" tabindex="-1"><a class="header-anchor" href="#is-registered" aria-hidden="true">#</a> is_registered</h3><p>\u8BF4\u660E\uFF1AProperty is registered as part of type registration</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="is-registered-optional" tabindex="-1"><a class="header-anchor" href="#is-registered-optional" aria-hidden="true">#</a> is_registered_optional</h3><p>\u8BF4\u660E\uFF1AProperty is \u53EF\u9009 ly registered as part of type registration</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="is-required" tabindex="-1"><a class="header-anchor" href="#is-required" aria-hidden="true">#</a> is_required</h3><p>\u8BF4\u660E\uFF1AFalse when this property is an \u53EF\u9009 argument in an RNA function</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="is-runtime" tabindex="-1"><a class="header-anchor" href="#is-runtime" aria-hidden="true">#</a> is_runtime</h3><p>\u8BF4\u660E\uFF1AProperty has been dynamically created at runtime</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="is-skip-save" tabindex="-1"><a class="header-anchor" href="#is-skip-save" aria-hidden="true">#</a> is_skip_save</h3><p>\u8BF4\u660E\uFF1ATrue when the property is not saved in presets</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="name-1" tabindex="-1"><a class="header-anchor" href="#name-1" aria-hidden="true">#</a> name</h3><p>\u8BF4\u660E\uFF1AHuman readable name</p><p>\u7C7B\u578B\uFF1A\u5B57\u7B26\u4E32\uFF0C\u9ED8\u8BA4\u4E3A&quot;&quot;\uFF0C\u53EA\u8BFB\uFF0C\u53EF\u9009</p><h3 id="srna" tabindex="-1"><a class="header-anchor" href="#srna" aria-hidden="true">#</a> srna</h3><p>\u8BF4\u660E\uFF1AStruct definition used for properties assigned to this item</p><p>\u7C7B\u578B\uFF1AStruct, \u53EA\u8BFB</p><h3 id="subtype-\u5B50\u7C7B\u578B" tabindex="-1"><a class="header-anchor" href="#subtype-\u5B50\u7C7B\u578B" aria-hidden="true">#</a> subtype \u5B50\u7C7B\u578B</h3><p>\u8BF4\u660E\uFF1A\u5C5E\u6027\u7684\u8BED\u4E49\u89E3\u91CA</p><p>\u7C7B\u578B\uFF1A\u4E0B\u9762\u4E4B\u4E00\uFF0C\u9ED8\u8BA4\u4E3A NONE\uFF0C \u53EA\u8BFB</p><ul><li>NONE\uFF1A\u65E0</li><li>FILEPATH\uFF1A\u6587\u4EF6\u8DEF\u5F84\uFF08\u8C8C\u4F3C\u662F FILE_PATH\uFF09</li><li>DIRPATH\uFF1A\u76EE\u5F55\u8DEF\u5F84\uFF08\u8C8C\u4F3C\u662F DIR_PATH\uFF09</li><li>FILENAME\uFF1A\u6587\u4EF6\u540D\u79F0\uFF08\u8C8C\u4F3C\u662F FILE_NAME\uFF09</li><li>BYTESTRING\uFF1AByte String.</li><li>PASSWORD\uFF1A\u5BC6\u7801 \u3002(<strong>****</strong>).</li><li>PIXEL\uFF1A\u50CF\u7D20</li><li>UNSIGNED\uFF1A\u65E0\u7B26\u53F7</li><li>PERCENTAGE\uFF1A\u767E\u5206\u6BD4</li><li>FACTOR\uFF1A\u7CFB\u6570\uFF08\u56E0\u5B50\uFF09</li><li>ANGLE\uFF1A\u89D2\u5EA6</li><li>TIME\uFF1A\u65F6\u95F4 (\u573A\u666F\u76F8\u5BF9) \u3002 \u4EE5\u5E27\u4E3A\u5355\u4F4D\uFF0C\u6839\u636E\u573A\u666F\u53EF\u4EE5\u8F6C\u4E3A\u79D2</li><li>TIME_ABSOLUTE\uFF1A\u65F6\u95F4 (\u573A\u666F\u7EDD\u5BF9) \u3002 \u4EE5\u79D2\u4E3A\u5355\u4F4D\u3002</li><li>DISTANCE\uFF1A\u8DDD\u79BB</li><li>DISTANCE_CAMERA\uFF1A\u6444\u50CF\u673A\u8DDD\u79BB</li><li>POWER\uFF1APower.</li><li>TEMPERATURE\uFF1A\u6E29\u5EA6</li><li>COLOR\uFF1A\u989C\u8272</li><li>TRANSLATION\uFF1A\u7FFB\u8BD1</li><li>DIRECTION\uFF1A\u65B9\u5411</li><li>VELOCITY\uFF1A\u901F\u5EA6</li><li>ACCELERATION\uFF1A\u52A0\u901F\u5EA6</li><li>MATRIX\uFF1A\u77E9\u9635</li><li>EULER\uFF1A\u6B27\u62C9\u89D2</li><li>QUATERNION\uFF1A\u56DB\u5143\u6570</li><li>AXISANGLE\uFF1A\u8F74-\u89D2</li><li>XYZ\uFF1AXYZ.</li><li>XYZ_LENGTH\uFF1AXYZ Length.</li><li>COLOR_GAMM\uFF1A Color.</li><li>COORDS\uFF1A\u5750\u6807</li><li>LAYER\uFF1A\u56FE\u5C42</li><li>LAYER_MEMBER\uFF1A\u56FE\u5C42\u6210\u5458</li></ul><h3 id="tags" tabindex="-1"><a class="header-anchor" href="#tags" aria-hidden="true">#</a> tags</h3><p>\u8BF4\u660E\uFF1ASubset of tags (defined in parent struct) that are set for this property</p><p>\u7C7B\u578B\uFF1A\u5728\u5B57\u5178\u4E2D\u95F4\u679A\u4E3E, \u9ED8\u8BA4\u4E3A{}, \u53EA\u8BFB</p><h3 id="translation-context" tabindex="-1"><a class="header-anchor" href="#translation-context" aria-hidden="true">#</a> translation_context</h3><p>\u8BF4\u660E\uFF1A\u8BE5\u5C5E\u6027\u540D\u79F0\u7684\u7FFB\u8BD1\u4E0A\u4E0B\u6587</p><p>\u7C7B\u578B\uFF1Astring, default \u201C\u201D, (\u53EA\u8BFB\uFF0C\u53EF\u9009)</p><h3 id="type" tabindex="-1"><a class="header-anchor" href="#type" aria-hidden="true">#</a> type</h3><p>\u8BF4\u660E\uFF1A\u5C5E\u6027\u7684\u6570\u636E\u7C7B\u578B</p><p>\u7C7B\u578B\uFF1A\u9ED8\u8BA4\u4E3A&quot;BOOLEAN&quot;\uFF0C\u53EA\u8BFB</p><ul><li>BOOLEAN</li><li>INT</li><li>FLOAT</li><li>STRING</li><li>ENUM</li><li>POINTER</li><li>COLLECTION</li></ul><h3 id="unit" tabindex="-1"><a class="header-anchor" href="#unit" aria-hidden="true">#</a> unit</h3><p>\u8BF4\u660E\uFF1AType of units for this property</p><p>\u7C7B\u578B\uFF1Aenum in [\u2018NONE\u2019, \u2018LENGTH\u2019, \u2018AREA\u2019, \u2018VOLUME\u2019, \u2018ROTATION\u2019, \u2018TIME\u2019,\u2018TIME_ABSOLUTE\u2019, \u2018VELOCITY\u2019, \u2018ACCELERATION\u2019, \u2018MASS\u2019, \u2018CAMERA\u2019, \u2018POWER\u2019,\u2018TEMPERATURE\u2019], default \u2018NONE\u2019, \u53EA\u8BFB</p><h3 id="classmethod-bl-rna-get-subclass-2" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-2" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py-2" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py-2" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><h2 id="propertygroup-bpy-struct" tabindex="-1"><a class="header-anchor" href="#propertygroup-bpy-struct" aria-hidden="true">#</a> PropertyGroup(bpy_struct)</h2><p>\u57FA\u7C7B\uFF1A bpy_struct</p><p>\u5B50\u7C7B\uFF1AAssetHandle, OperatorFileListElement, OperatorMousePath,OperatorStrokeElement, SelectedUvElement</p><p>\u8BF4\u660E\uFF1APropertyGroups \u662F\u52A8\u6001\u5B9A\u4E49\u7684\u5C5E\u6027\u96C6\u7684\u57FA\u7C7B\u3002</p><p>\u53EF\u4EE5\u7528\u81EA\u5DF1\u7684\u7C7B\u578B\u6765\u6269\u5C55\u73B0\u6709\u7684 Blender \u6570\u636E\uFF0C\u8FD9\u4E9B\u7C7B\u578B\u53EF\u4EE5\u88AB\u52A8\u753B\u5316\uFF0C\u4E5F\u53EF\u4EE5\u4ECE\u7528\u6237\u754C\u9762\u548C python \u4E2D\u8BBF\u95EE\u3002</p><p><strong>\u6CE8\u610F\uFF1A</strong></p><p>1.\u5C5E\u6027\u7EC4\uFF08PropertyGroups\uFF09\u5728\u5206\u914D\u7ED9 Blender \u6570\u636E\u524D\uFF0C\u5FC5\u987B\u6CE8\u518C</p><p>2.\u5206\u914D\u7ED9 blender \u6570\u636E\u7684\u503C\u4FDD\u5B58\u5728\u78C1\u76D8\u4E0A\uFF0C\u4F46\u7C7B\u7684\u5B9A\u4E49\u5374\u6CA1\u6709\uFF0C\u6240\u4EE5\u6BCF\u5F53\u52A0\u8F7D blender \u65F6\uFF0C\u7C7B\u4E5F\u9700\u8981\u6CE8\u518C\u3002\u6700\u597D\u63D2\u4EF6\u5728\u542F\u52A8\u65F6\u52A0\u8F7D\u5E76\u6CE8\u518C\u4F60\u7684\u5C5E\u6027\u3002</p><p>3.Property \u7C7B\u578B\u90FD\u662F\u5728 bpy.props \u4E2D\u8FDB\u884C\u7533\u660E</p><p><strong>\u4EBA\u8BDD\uFF08\u4E2A\u4EBA\u7406\u89E3\uFF09\uFF1A</strong></p><p>\u81EA\u5B9A\u4E49\u7684\u7C7B\uFF0C\u7EE7\u627F PropertyGroup \u540E\uFF0C\u91CC\u9762\u6240\u6709\u7684 RNA \u5B9A\u4E49\u90FD\u53EF\u4EE5\u76F4\u63A5\u4F5C\u4E3A\u5C5E\u6027\u4F20\u5165\u3002\u518D\u7528\u4E00\u4E2A\u53D8\u91CF\u63A5\u6536\uFF0C\u5373\u53EF\u5B8C\u6210\u591A\u4E2A\u5C5E\u6027\u4F20\u9012\u3002</p><h3 id="\u793A\u4F8B" tabindex="-1"><a class="header-anchor" href="#\u793A\u4F8B" aria-hidden="true">#</a> \u793A\u4F8B</h3><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code><span class="token keyword">import</span> bpy <span class="token comment"># \u521B\u5EFA\uFF08\u7C7B\uFF09\u5C5E\u6027 class</span>
MyPropertyGroup<span class="token punctuation">(</span>bpy<span class="token punctuation">.</span>types<span class="token punctuation">.</span>PropertyGroup<span class="token punctuation">)</span><span class="token punctuation">:</span> custom_1<span class="token punctuation">:</span>bpy<span class="token punctuation">.</span>props<span class="token punctuation">.</span>FloatProperty<span class="token punctuation">(</span>name<span class="token operator">=</span><span class="token string">&quot;My Float&quot;</span><span class="token punctuation">)</span> <span class="token comment"># \u6CE8\u610FRNA\u5C5E\u6027\u7528 : \u8FDB\u884C\u5B9A\u4E49 custom_2:bpy.props.IntProperty(name=&quot;My Int&quot;) # \u6CE8\u518C\u7C7Bbpy.utils.register_class(MyPropertyGroup) # \u5BF9Object\u7C7B\uFF0C\u6DFB\u52A0\u4E00\u4E2A\u53C2\u6570bpy.types.Object.my_prop_grp = bpy.props.PointerProperty(type=MyPropertyGroup)# \u7ED9\u4E00\u4E2Aobject\u6DFB\u52A0\u81EA\u5B9A\u4E49\u5C5E\u6027 bpy.data.objects[0].my_prop_grp.custom_1 = 22.0</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="classbpy-types-propertygroup" tabindex="-1"><a class="header-anchor" href="#classbpy-types-propertygroup" aria-hidden="true">#</a> classbpy.types.PropertyGroup()</h3><p>\u5168\u540D\uFF1Aclassbpy.types.PropertyGroup(bpy_struct)</p><p>\u8BF4\u660E\uFF1AGroup of ID properties</p><h3 id="name-2" tabindex="-1"><a class="header-anchor" href="#name-2" aria-hidden="true">#</a> name</h3><p>\u8BF4\u660E\uFF1AUnique name used in the code and scripting</p><p>\u7C7B\u578B\uFF1Astring, default \u201C\u201D, \u4E0D\u4F1A\u4E3A None</p><h3 id="classmethod-bl-rna-get-subclass-3" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-3" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py-3" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py-3" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><h2 id="propertygroupitem-bpy-struct" tabindex="-1"><a class="header-anchor" href="#propertygroupitem-bpy-struct" aria-hidden="true">#</a> PropertyGroupItem(bpy_struct)</h2><p>\u57FA\u7C7B\uFF1A bpy_struct</p><p>\u8BF4\u660E\uFF1A\u50A8\u5B58\u4EFB\u610F\u3001\u7528\u6237\u5B9A\u4E49\u7684\u5C5E\u6027</p><h3 id="collection" tabindex="-1"><a class="header-anchor" href="#collection" aria-hidden="true">#</a> collection</h3><p>\u8BF4\u660E\uFF1A</p><p>\u7C7B\u578B\uFF1Abpy_prop_collection of PropertyGroup, \u53EA\u8BFB</p><h3 id="double" tabindex="-1"><a class="header-anchor" href="#double" aria-hidden="true">#</a> double</h3><p>\u8BF4\u660E\uFF1A</p><p>\u7C7B\u578B\uFF1Afloat in [-inf, inf], default 0.0</p><h3 id="double-array" tabindex="-1"><a class="header-anchor" href="#double-array" aria-hidden="true">#</a> double_array</h3><p>\u8BF4\u660E\uFF1A</p><p>\u7C7B\u578B\uFF1Afloat array of 1 items in [-inf, inf], default (0.0)</p><h3 id="float" tabindex="-1"><a class="header-anchor" href="#float" aria-hidden="true">#</a> float</h3><p>\u8BF4\u660E\uFF1A</p><p>\u7C7B\u578B\uFF1Afloat in [-inf, inf], default 0.0</p><h3 id="float-array" tabindex="-1"><a class="header-anchor" href="#float-array" aria-hidden="true">#</a> float_array</h3><p>\u8BF4\u660E\uFF1A</p><p>\u7C7B\u578B\uFF1Afloat array of 1 items in [-inf, inf], default (0.0)</p><h3 id="group" tabindex="-1"><a class="header-anchor" href="#group" aria-hidden="true">#</a> group</h3><p>\u8BF4\u660E\uFF1A\u7C7B\u578B\uFF1APropertyGroup, \u53EA\u8BFB</p><h3 id="id" tabindex="-1"><a class="header-anchor" href="#id" aria-hidden="true">#</a> id</h3><p>\u8BF4\u660E\uFF1A</p><p>\u7C7B\u578B\uFF1AID</p><h3 id="idp-array" tabindex="-1"><a class="header-anchor" href="#idp-array" aria-hidden="true">#</a> idp_array</h3><p>\u8BF4\u660E\uFF1A</p><p>\u7C7B\u578B\uFF1Abpy_prop_collection of PropertyGroup, \u53EA\u8BFB</p><h3 id="int" tabindex="-1"><a class="header-anchor" href="#int" aria-hidden="true">#</a> int</h3><p>\u8BF4\u660E\uFF1A\u7C7B\u578B\uFF1Aint in [-inf, inf], default 0</p><h3 id="int-array" tabindex="-1"><a class="header-anchor" href="#int-array" aria-hidden="true">#</a> int_array</h3><p>\u8BF4\u660E\uFF1A</p><p>\u7C7B\u578B\uFF1Aint array of 1 items in [-inf, inf], default (0,)</p><h3 id="string" tabindex="-1"><a class="header-anchor" href="#string" aria-hidden="true">#</a> string</h3><p>\u8BF4\u660E\uFF1A</p><p>\u7C7B\u578B\uFF1Astring, default \u201C\u201D, \u4E0D\u4F1A\u4E3A None</p><h3 id="classmethod-bl-rna-get-subclass-4" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-4" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py-4" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py-4" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><h2 id="boolattribute-attribute" tabindex="-1"><a class="header-anchor" href="#boolattribute-attribute" aria-hidden="true">#</a> BoolAttribute(Attribute)</h2><p>\u57FA\u7C7B\uFF1A bpy_struct, Attribute</p><p>\u8BF4\u660E\uFF1A\u51E0\u4F55\u5C5E\u6027\u5E03\u5C14\u503C</p><h3 id="data" tabindex="-1"><a class="header-anchor" href="#data" aria-hidden="true">#</a> data</h3><p>\u8BF4\u660E\uFF1A<br> \u7C7B\u578B\uFF1Abpy_prop_collection of BoolAttributeValue, \u53EA\u8BFB</p><h3 id="classmethod-bl-rna-get-subclass-5" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-5" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py-5" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py-5" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><h2 id="bytecolorattribute-attribute" tabindex="-1"><a class="header-anchor" href="#bytecolorattribute-attribute" aria-hidden="true">#</a> ByteColorAttribute(Attribute)</h2><p>\u57FA\u7C7B\uFF1A bpy_struct, Attribute</p><p>Color geometry attribute, with 8-bit values</p><h3 id="data-1" tabindex="-1"><a class="header-anchor" href="#data-1" aria-hidden="true">#</a> data</h3><p>\u8BF4\u660E\uFF1A<br> \u7C7B\u578B\uFF1Abpy_prop_collection of ByteColorAttributeValue, \u53EA\u8BFB</p><h3 id="classmethod-bl-rna-get-subclass-6" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-6" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py-6" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py-6" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><h2 id="float2attribute-attribute" tabindex="-1"><a class="header-anchor" href="#float2attribute-attribute" aria-hidden="true">#</a> Float2Attribute(Attribute)</h2><p>\u57FA\u7C7B\uFF1A bpy_struct, Attribute</p><h3 id="classbpy-types-float2attribute" tabindex="-1"><a class="header-anchor" href="#classbpy-types-float2attribute" aria-hidden="true">#</a> classbpy.types.Float2Attribute()</h3><p>\u5168\u540D\uFF1Aclassbpy.types.Float2Attribute(Attribute)</p><p>2D vector geometry attribute, with floating-point values</p><h3 id="data-2" tabindex="-1"><a class="header-anchor" href="#data-2" aria-hidden="true">#</a> data</h3><p>\u8BF4\u660E\uFF1A<br> \u7C7B\u578B\uFF1Abpy_prop_collection of Float2AttributeValue, \u53EA\u8BFB</p><h3 id="classmethod-bl-rna-get-subclass-7" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-7" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py-7" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py-7" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><h2 id="floatattribute-attribute" tabindex="-1"><a class="header-anchor" href="#floatattribute-attribute" aria-hidden="true">#</a> FloatAttribute(Attribute)</h2><p>\u57FA\u7C7B\uFF1A bpy_struct, Attribute</p><h3 id="classbpy-types-floatattribute" tabindex="-1"><a class="header-anchor" href="#classbpy-types-floatattribute" aria-hidden="true">#</a> classbpy.types.FloatAttribute()</h3><p>\u5168\u540D\uFF1Aclassbpy.types.FloatAttribute(Attribute)</p><p>Geometry attribute with floating-point values</p><h3 id="data-3" tabindex="-1"><a class="header-anchor" href="#data-3" aria-hidden="true">#</a> data</h3><p>\u8BF4\u660E\uFF1A<br> \u7C7B\u578B\uFF1Abpy_prop_collection of FloatAttributeValue, \u53EA\u8BFB</p><h3 id="classmethod-bl-rna-get-subclass-8" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-8" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py-8" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py-8" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><h2 id="floatcolorattribute-attribute" tabindex="-1"><a class="header-anchor" href="#floatcolorattribute-attribute" aria-hidden="true">#</a> FloatColorAttribute(Attribute)</h2><p>\u57FA\u7C7B\uFF1A bpy_struct, Attribute</p><h3 id="classbpy-types-floatcolorattribute" tabindex="-1"><a class="header-anchor" href="#classbpy-types-floatcolorattribute" aria-hidden="true">#</a> classbpy.types.FloatColorAttribute()</h3><p>\u5168\u540D\uFF1Aclassbpy.types.FloatColorAttribute(Attribute)</p><p>Color geometry attribute, with floating-point values</p><h3 id="data-4" tabindex="-1"><a class="header-anchor" href="#data-4" aria-hidden="true">#</a> data</h3><p>\u8BF4\u660E\uFF1A<br> \u7C7B\u578B\uFF1Abpy_prop_collection of FloatColorAttributeValue, \u53EA\u8BFB</p><h3 id="classmethod-bl-rna-get-subclass-9" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-9" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py-9" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py-9" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><h2 id="floatvectorattribute-attribute" tabindex="-1"><a class="header-anchor" href="#floatvectorattribute-attribute" aria-hidden="true">#</a> FloatVectorAttribute(Attribute)</h2><p>\u57FA\u7C7B\uFF1A bpy_struct, Attribute</p><h3 id="classbpy-types-floatvectorattribute" tabindex="-1"><a class="header-anchor" href="#classbpy-types-floatvectorattribute" aria-hidden="true">#</a> classbpy.types.FloatVectorAttribute()</h3><p>\u5168\u540D\uFF1Aclassbpy.types.FloatVectorAttribute(Attribute)</p><p>Vector geometry attribute, with floating-point values</p><h3 id="data-5" tabindex="-1"><a class="header-anchor" href="#data-5" aria-hidden="true">#</a> data</h3><p>\u8BF4\u660E\uFF1A<br> \u7C7B\u578B\uFF1Abpy_prop_collection of FloatVectorAttributeValue, \u53EA\u8BFB</p><h3 id="classmethod-bl-rna-get-subclass-10" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-10" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py-10" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py-10" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><h2 id="intattribute-attribute" tabindex="-1"><a class="header-anchor" href="#intattribute-attribute" aria-hidden="true">#</a> IntAttribute(Attribute)</h2><p>\u57FA\u7C7B\uFF1A bpy_struct, Attribute</p><h3 id="classbpy-types-intattribute" tabindex="-1"><a class="header-anchor" href="#classbpy-types-intattribute" aria-hidden="true">#</a> classbpy.types.IntAttribute()</h3><p>\u5168\u540D\uFF1Aclassbpy.types.IntAttribute(Attribute)</p><p>Integer geometry attribute</p><h3 id="data-6" tabindex="-1"><a class="header-anchor" href="#data-6" aria-hidden="true">#</a> data</h3><p>\u8BF4\u660E\uFF1A<br> \u7C7B\u578B\uFF1Abpy_prop_collection of IntAttributeValue, \u53EA\u8BFB</p><h3 id="classmethod-bl-rna-get-subclass-11" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-11" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py-11" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py-11" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><h2 id="stringattribute-attribute" tabindex="-1"><a class="header-anchor" href="#stringattribute-attribute" aria-hidden="true">#</a> StringAttribute(Attribute)</h2><p>\u57FA\u7C7B\uFF1A bpy_struct, Attribute</p><h3 id="classbpy-types-stringattribute" tabindex="-1"><a class="header-anchor" href="#classbpy-types-stringattribute" aria-hidden="true">#</a> classbpy.types.StringAttribute()</h3><p>\u5168\u540D\uFF1Aclassbpy.types.StringAttribute(Attribute)</p><p>String geometry attribute</p><h3 id="data-7" tabindex="-1"><a class="header-anchor" href="#data-7" aria-hidden="true">#</a> data</h3><p>\u8BF4\u660E\uFF1A<br> \u7C7B\u578B\uFF1Abpy_prop_collection of StringAttributeValue, \u53EA\u8BFB</p><h3 id="classmethod-bl-rna-get-subclass-12" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-12" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py-12" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py-12" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><h2 id="boolproperty-property" tabindex="-1"><a class="header-anchor" href="#boolproperty-property" aria-hidden="true">#</a> BoolProperty(Property)</h2><p>\u57FA\u7C7B\uFF1Abpy_struct, Property</p><p>\u8BF4\u660E\uFF1A\u5B9A\u4E49 RNA \u7684\u5E03\u5C14\u5C5E\u6027</p><h3 id="\u793A\u4F8B-1" tabindex="-1"><a class="header-anchor" href="#\u793A\u4F8B-1" aria-hidden="true">#</a> \u793A\u4F8B</h3><p>name\u3001description\u3001default \u90FD\u662F\u7EE7\u627F\u4E8E\u7236\u7C7B Property</p><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code>my_bool<span class="token punctuation">:</span> bpy<span class="token punctuation">.</span>props<span class="token punctuation">.</span>BoolProperty<span class="token punctuation">(</span> name<span class="token operator">=</span><span class="token string">&quot;\u5F00/\u5173&quot;</span><span class="token punctuation">,</span> description<span class="token operator">=</span><span class="token string">&quot;\u6211\u662F\u5E03\u5C14\u7C7B\u578B&quot;</span><span class="token punctuation">,</span>
default <span class="token operator">=</span> <span class="token boolean">False</span> <span class="token punctuation">)</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="array-dimensions" tabindex="-1"><a class="header-anchor" href="#array-dimensions" aria-hidden="true">#</a> array_dimensions</h3><p>\u8BF4\u660E\uFF1ALength of each dimension of the array</p><p>\u7C7B\u578B\uFF1Aint array of 3 items in [0, inf], default (0, 0, 0), \u53EA\u8BFB</p><h3 id="array-length" tabindex="-1"><a class="header-anchor" href="#array-length" aria-hidden="true">#</a> array_length</h3><p>\u8BF4\u660E\uFF1AMaximum length of the array, 0 means unlimited</p><p>\u7C7B\u578B\uFF1Aint in [0, inf], default 0, \u53EA\u8BFB</p><h3 id="default" tabindex="-1"><a class="header-anchor" href="#default" aria-hidden="true">#</a> default</h3><p>\u8BF4\u660E\uFF1ADefault value for this number</p><p>\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="default-array" tabindex="-1"><a class="header-anchor" href="#default-array" aria-hidden="true">#</a> default_array</h3><p>\u8BF4\u660E\uFF1ADefault value for this array</p><p>\u7C7B\u578B\uFF1Aboolean array of 3 items, default (False, False, False), \u53EA\u8BFB</p><h3 id="is-array" tabindex="-1"><a class="header-anchor" href="#is-array" aria-hidden="true">#</a> is_array</h3><p>\u8BF4\u660E\uFF1A\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB</p><h3 id="classmethod-bl-rna-get-subclass-13" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-13" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py-13" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py-13" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><h2 id="collectionproperty-property" tabindex="-1"><a class="header-anchor" href="#collectionproperty-property" aria-hidden="true">#</a> CollectionProperty(Property)</h2><p>\u57FA\u7C7B\uFF1Abpy_struct, Property</p><p>\u8BF4\u660E\uFF1ARNA \u96C6\u5408\u5C5E\u6027\u7528\u4E8E\u5B9A\u4E49 lists, arrays and mappings</p><h3 id="fixed-type" tabindex="-1"><a class="header-anchor" href="#fixed-type" aria-hidden="true">#</a> fixed_type</h3><p>\u8BF4\u660E\uFF1AFixed pointer type, empty if variable type</p><p>\u7C7B\u578B\uFF1AStruct, \u53EA\u8BFB</p><h3 id="classmethod-bl-rna-get-subclass-14" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-14" aria-hidden="true">#</a> classmethod bl_rna_get_subclass()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1ARNA \u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass</p><h3 id="classmethod-bl-rna-get-subclass-py-14" tabindex="-1"><a class="header-anchor" href="#classmethod-bl-rna-get-subclass-py-14" aria-hidden="true">#</a> classmethod bl_rna_get_subclass_py()</h3><p>\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)</p><p>\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.</p><p>\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002</p><p>\u8FD4\u56DE\u7C7B\u578B\uFF1Atype</p><hr><h3 id="\u793A\u4F8B-2" tabindex="-1"><a class="header-anchor" href="#\u793A\u4F8B-2" aria-hidden="true">#</a> \u793A\u4F8B</h3><div class="language-python ext-py line-numbers-mode"><pre class="language-python"><code><span class="token keyword">from</span> bpy<span class="token punctuation">.</span>types <span class="token keyword">import</span> PropertyGroup <span class="token comment"># \u5B9A\u4E49 class</span>
ListItem<span class="token punctuation">(</span>PropertyGroup<span class="token punctuation">)</span><span class="token punctuation">:</span> <span class="token triple-quoted-string string">&quot;&quot;&quot;\u4EE3\u8868\u5217\u8868\u4E2D\u4E00\u4E2A\u9879\u76EE\u7684\u5C5E\u6027\u7EC4&quot;&quot;&quot;</span> prop1<span class="token punctuation">:</span> StringProperty<span class="token punctuation">(</span>name<span class="token operator">=</span><span class="token string">&quot;propp1&quot;</span><span class="token punctuation">,</span> description<span class="token operator">=</span><span class="token string">&quot;\u4E00\u4E2A\u5C5E\u6027&quot;</span><span class="token punctuation">,</span> default<span class="token operator">=</span><span class="token string">&quot;\u5C5E\u60271&quot;</span><span class="token punctuation">)</span> prop2<span class="token punctuation">:</span> StringProperty<span class="token punctuation">(</span>name<span class="token operator">=</span><span class="token string">&quot;propp2&quot;</span><span class="token punctuation">,</span> description<span class="token operator">=</span><span class="token string">&quot;\u53E6\u4E00\u4E2A\u5C5E\u6027&quot;</span><span class="token punctuation">,</span> default<span class="token operator">=</span><span class="token string">&quot;\u5C5E\u60272&quot;</span><span class="token punctuation">)</span> <span class="token comment"># \u4F7F\u7528bpy.types.Scene.my_list = CollectionProperty(type=ListItem) # type\u7EE7\u627F\u7236\u7C7BProperty\uFF1F class XX() def execute(self, context): my_list =context.scene.my_list # \u4ECEscene\u4E2D\u83B7\u53D6my_lsit my_list.add() # \u6DFB\u52A0\u9879 index =context.scene.list_index my_list.remove(index) # \u5220\u9664\u9879 my_list.move(index + 1,index) # \u79FB\u52A8\u9879\uFF0C\u793A\u4F8B\u4E3A\u5411\u4E0B\u79FB\u52A81 my_list.clear() #\u6E05\u7A7A\u9879 return{&#39;FINISHED&#39;}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div></div></div><p>\u4EE5\u4E0B\u975E\u5B98\u65B9\u6587\u6863\uFF0C\u4E3A\u67E5\u770B\u5176\u5B83\u793A\u4F8B\u4EE5\u53CA\u4E2A\u4EBA\u627E\u5230\u7684\u3002</p><p><img src="https://cdn.yuelili.com/20220117000319.png" alt=""></p><h3 id="add" tabindex="-1"><a class="header-anchor" href="#add" aria-hidden="true">#</a> add()</h3><p>\u8BF4\u660E\uFF1A\u6DFB\u52A0\u9879</p><h3 id="clear" tabindex="-1"><a class="header-anchor" href="#clear" aria-hidden="true">#</a> clear()</h3><p>\u8BF4\u660E\uFF1A\u6E05\u7A7A\u6240\u6709\u9879</p><h3 id="move" tabindex="-1"><a class="header-anchor" href="#move" aria-hidden="true">#</a> move()</h3><p>\u5168\u540D\uFF1AXX list.move(trg , src)</p><p>\u8BF4\u660E\uFF1A\u79FB\u52A8\u9879</p><p>\u53C2\u6570\uFF1A</p><ul><li>trg\uFF1A\u76EE\u6807\u7D22\u5F15</li><li>src\uFF1A\u88AB\u79FB\u52A8\u7684\u7D22\u5F15</li></ul><h3 id="remove-1" tabindex="-1"><a class="header-anchor" href="#remove-1" aria-hidden="true">#</a> remove()</h3><p>\u8BF4\u660E\uFF1A\u79FB\u9664\u9879</p><p>\u53C2\u6570\uFF1A\u6307\u5B9A\u4E00\u4E2A\u7D22\u5F15\uFF0C\u6CA1\u5565\u597D\u8BF4\u7684</p><h2 id="enumproperty-property" tabindex="-1"><a class="header-anchor" href="#enumproperty-property" aria-hidden="true">#</a> EnumProperty(Property)</h2><p>\u57FA\u7C7B\uFF1Abpy_struct, Property</p><p>\u8BF4\u660E\uFF1ARNA \u679A\u4E3E\u5C5E\u6027\u5B9A\u4E49\uFF0C\u7528\u4E8E\u4ECE\u9884\u8BBE\u9009\u9879\u4E2D\u9009\u53D6</p><h3 id="\u793A\u4F8B-3" tabindex="-1"><a class="header-anchor" href="#\u793A\u4F8B-3" aria-hidden="true">#</a> \u793A\u4F8B</h3><pre><code>    my_enum: EnumProperty(

        name=&quot;Dropdown:&quot;,

        description=&quot;Apply Data to attribute.&quot;,

        items=[ (&#39;OP1&#39;, &quot;\u9009\u9879 1&quot;, &quot;&quot;),

                (&#39;OP2&#39;, &quot;\u9009\u9879 2&quot;, &quot;&quot;),

                (&#39;OP3&#39;, &quot;\u9009\u9879 3&quot;, &quot;&quot;),

               ]

        )
</code></pre><div class="language-text ext-text line-numbers-mode"><pre class="language-text"><code>

     




    ## default #




    \u8BF4\u660E\uFF1ADefault value for this enum




    \u7C7B\u578B\uFF1Aenum in [\u2018DUMMY\u2019], default \u2018DUMMY\u2019, \u53EA\u8BFB




    ## default_flag #




    \u8BF4\u660E\uFF1ADefault value for this enum




    \u7C7B\u578B\uFF1Aenum set in {\u2018DUMMY\u2019}, default {}, \u53EA\u8BFB




    ## enum_items #




    \u8BF4\u660E\uFF1APossible values for the property




    \u7C7B\u578B\uFF1Abpy_prop_collection of EnumPropertyItem, \u53EA\u8BFB




    ## enum_items_static #




    \u8BF4\u660E\uFF1APossible values for the property (never calls \u53EF\u9009 dynamic generation of those)




    \u7C7B\u578B\uFF1Abpy_prop_collection of EnumPropertyItem, \u53EA\u8BFB




    ## classmethod bl_rna_get_subclass() #




    \u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)




    \u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.




    \u8FD4\u56DE\uFF1ARNA\u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




    \u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass




    ## classmethod bl_rna_get_subclass_py() #




    \u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)




    \u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.




    \u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




    \u8FD4\u56DE\u7C7B\u578B\uFF1Atype




    # EnumPropertyItem(bpy_struct) #




    \u57FA\u7C7B\uFF1A bpy_struct




    \u8BF4\u660E\uFF1A\u5B9A\u4E49\u5728RNA\u679A\u4E3E\u5C5E\u6027\u4E2D\u7684\u4E00\u4E2A\u9009\u9879




    ## description #




    \u8BF4\u660E\uFF1ADescription of the item\u2019s purpose




    \u7C7B\u578B\uFF1A\u5B57\u7B26\u4E32\uFF0C\u9ED8\u8BA4\u4E3A&quot;&quot;\uFF0C\u53EA\u8BFB\uFF0C\u53EF\u9009




    ## icon #




    \u8BF4\u660E\uFF1AIcon of the item




    \u7C7B\u578B\uFF1AIcon\u56FE\u6807




    ## identifier #




    \u8BF4\u660E\uFF1AUnique name used in the code and scripting




    \u7C7B\u578B\uFF1A\u5B57\u7B26\u4E32\uFF0C\u9ED8\u8BA4\u4E3A&quot;&quot;\uFF0C\u53EA\u8BFB\uFF0C\u53EF\u9009




    ## name #




    \u8BF4\u660E\uFF1AHuman readable name




    \u7C7B\u578B\uFF1Astring, default \u201C\u201D, (\u53EA\u8BFB\uFF0C\u53EF\u9009)




    ## value #




    \u8BF4\u660E\uFF1AValue of the item




    \u7C7B\u578B\uFF1Aint in [0, inf], default 0, \u53EA\u8BFB




    ## classmethod bl_rna_get_subclass() #




    \u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)




    \u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.




    \u8FD4\u56DE\uFF1ARNA\u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




    \u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass




    ## classmethod bl_rna_get_subclass_py() #




    \u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)




    \u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.




    \u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




    \u8FD4\u56DE\u7C7B\u578B\uFF1Atype




    # FloatProperty(Property) #




    \u57FA\u7C7B\uFF1Abpy_struct, Property




    \u8BF4\u660E\uFF1ARNA floating-point number (single precision) property definition




    ## \u793A\u4F8B #





        my_float: FloatProperty(

            name = &quot;\u6D6E\u70B9\u503C&quot;,

            description = &quot;\u6211\u662F\u6D6E\u70B9\u503C&quot;,

            default = 23.7,

            min = 0.01,

            max = 30.0

            )


</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><pre><code>## array_dimensions #




\u8BF4\u660E\uFF1ALength of each dimension of the array




\u7C7B\u578B\uFF1Aint array of 3 items in [0, inf], default (0, 0, 0), \u53EA\u8BFB




## array_length #




\u8BF4\u660E\uFF1AMaximum length of the array, 0 means unlimited




\u7C7B\u578B\uFF1Aint in [0, inf], default 0, \u53EA\u8BFB




## default #




\u8BF4\u660E\uFF1ADefault value for this number




\u7C7B\u578B\uFF1Afloat in [-inf, inf], default 0.0, \u53EA\u8BFB




## default_array #




\u8BF4\u660E\uFF1ADefault value for this array




\u7C7B\u578B\uFF1Afloat array of 3 items in [-inf, inf], default (0.0, 0.0, 0.0), \u53EA\u8BFB




## hard_max #




\u8BF4\u660E\uFF1AMaximum value used by buttons




\u7C7B\u578B\uFF1Afloat in [-inf, inf], default 0.0, \u53EA\u8BFB




## hard_min #




\u8BF4\u660E\uFF1AMinimum value used by buttons




\u7C7B\u578B\uFF1Afloat in [-inf, inf], default 0.0, \u53EA\u8BFB




## is_array #




\u8BF4\u660E\uFF1A\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB




## precision #




\u8BF4\u660E\uFF1ANumber of digits after the dot used by buttons




\u7C7B\u578B\uFF1Aint in [0, inf], default 0, \u53EA\u8BFB




## soft_max #




\u8BF4\u660E\uFF1AMaximum value used by buttons




\u7C7B\u578B\uFF1Afloat in [-inf, inf], default 0.0, \u53EA\u8BFB




## soft_min #




\u8BF4\u660E\uFF1AMinimum value used by buttons




\u7C7B\u578B\uFF1Afloat in [-inf, inf], default 0.0, \u53EA\u8BFB




## step #




\u8BF4\u660E\uFF1AStep size used by number buttons, for floats 1/100th of the step size




\u7C7B\u578B\uFF1Afloat in [0, inf], default 0.0, \u53EA\u8BFB




## classmethod bl_rna_get_subclass() #




\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)




\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.




\u8FD4\u56DE\uFF1ARNA\u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass




## classmethod bl_rna_get_subclass_py() #




\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)




\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.




\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




\u8FD4\u56DE\u7C7B\u578B\uFF1Atype




# IntProperty(Property) #




\u57FA\u7C7B\uFF1Abpy_struct, Property




\u8BF4\u660E\uFF1ARNA integer number property definition




## \u793A\u4F8B #


\`\`\`python
my_int: IntProperty(

        name = &quot;\u6574\u6570\u7C7B\u578B&quot;,

        description=&quot;\u6211\u662F\u6574\u578B&quot;,

        default = 23,

        min = 10,

        max = 100

        )
</code></pre><div class="language-text ext-text line-numbers-mode"><pre class="language-text"><code>

     




    ## array_dimensions #




    \u8BF4\u660E\uFF1ALength of each dimension of the array




    \u7C7B\u578B\uFF1Aint array of 3 items in [0, inf], default (0, 0, 0), \u53EA\u8BFB




    ## array_length #




    \u8BF4\u660E\uFF1AMaximum length of the array, 0 means unlimited




    \u7C7B\u578B\uFF1Aint in [0, inf], default 0, \u53EA\u8BFB




    ## default #




    \u8BF4\u660E\uFF1ADefault value for this number




    \u7C7B\u578B\uFF1Aint in [-inf, inf], default 0, \u53EA\u8BFB




    ## default_array #




    \u8BF4\u660E\uFF1ADefault value for this array




    \u7C7B\u578B\uFF1Aint array of 3 items in [-inf, inf], default (0, 0, 0), \u53EA\u8BFB




    ## hard_max #




    \u8BF4\u660E\uFF1AMaximum value used by buttons




    \u7C7B\u578B\uFF1Aint in [-inf, inf], default 0, \u53EA\u8BFB




    ## hard_min #




    \u8BF4\u660E\uFF1AMinimum value used by buttons




    \u7C7B\u578B\uFF1Aint in [-inf, inf], default 0, \u53EA\u8BFB




    ## is_array #




    \u8BF4\u660E\uFF1A\u7C7B\u578B\uFF1Aboolean, default False, \u53EA\u8BFB




    ## soft_max #




    \u8BF4\u660E\uFF1AMaximum value used by buttons




    \u7C7B\u578B\uFF1Aint in [-inf, inf], default 0, \u53EA\u8BFB




    ## soft_min #




    \u8BF4\u660E\uFF1AMinimum value used by buttons




    \u7C7B\u578B\uFF1Aint in [-inf, inf], default 0, \u53EA\u8BFB




    ## step #




    \u8BF4\u660E\uFF1AStep size used by number buttons, for floats 1/100th of the step size




    \u7C7B\u578B\uFF1Aint in [0, inf], default 0, \u53EA\u8BFB




    ## classmethod bl_rna_get_subclass() #




    \u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)




    \u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.




    \u8FD4\u56DE\uFF1ARNA\u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




    \u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass




    ## classmethod bl_rna_get_subclass_py() #




    \u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)




    \u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.




    \u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




    \u8FD4\u56DE\u7C7B\u578B\uFF1Atype




     




    # PointerProperty(Property) #




    \u57FA\u7C7B\uFF1Abpy_struct, Property




    \u8BF4\u660E\uFF1ARNA pointer property to point to another RNA struct




    ## fixed_type #




    \u8BF4\u660E\uFF1AFixed pointer type, empty if variable type




    \u7C7B\u578B\uFF1AStruct, \u53EA\u8BFB




    ## classmethod bl_rna_get_subclass() #




    \u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)




    \u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.




    \u8FD4\u56DE\uFF1ARNA\u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




    \u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass




    ## classmethod bl_rna_get_subclass_py() #




    \u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)




    \u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.




    \u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




    \u8FD4\u56DE\u7C7B\u578B\uFF1Atype




    # StringProperty(Property) #




    \u57FA\u7C7B\uFF1Abpy_struct, Property




    \u8BF4\u660E\uFF1ARNA text string property definition




    ## \u793A\u4F8B #


    \`\`\`python
    my_string: StringProperty(

            name=&quot;\u7528\u6237\u8F93\u5165&quot;,

            description=&quot;:&quot;,

            default=&quot;&quot;,

            maxlen=1024,

            )


</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><pre><code>## default #




\u8BF4\u660E\uFF1AString default value




\u7C7B\u578B\uFF1Astring, default \u201C\u201D, (\u53EA\u8BFB\uFF0C\u53EF\u9009)




## length_max #




\u8BF4\u660E\uFF1AMaximum length of the string, 0 means unlimited




\u7C7B\u578B\uFF1Aint in [0, inf], default 0, \u53EA\u8BFB




## classmethod bl_rna_get_subclass() #




\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)




\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.




\u8FD4\u56DE\uFF1ARNA\u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass




## classmethod bl_rna_get_subclass_py() #




\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)




\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.




\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




\u8FD4\u56DE\u7C7B\u578B\uFF1Atype




# Struct(bpy_struct) #




\u57FA\u7C7B\uFF1A bpy_struct




\u8BF4\u660E\uFF1ARNA structure definition




## base #




\u8BF4\u660E\uFF1AStruct definition this is derived from




\u7C7B\u578B\uFF1AStruct, \u53EA\u8BFB




## description #




\u8BF4\u660E\uFF1ADescription of the Struct\u2019s purpose




\u7C7B\u578B\uFF1Astring, default \u201C\u201D, (\u53EA\u8BFB\uFF0C\u53EF\u9009)




## functions #




\u8BF4\u660E\uFF1A\u7C7B\u578B\uFF1Abpy_prop_collection of Function, \u53EA\u8BFB




## identifier #




\u8BF4\u660E\uFF1AUnique name used in the code and scripting




\u7C7B\u578B\uFF1Astring, default \u201C\u201D, (\u53EA\u8BFB\uFF0C\u53EF\u9009)




## name #




\u8BF4\u660E\uFF1AHuman readable name




\u7C7B\u578B\uFF1Astring, default \u201C\u201D, (\u53EA\u8BFB\uFF0C\u53EF\u9009)




## name_property #




\u8BF4\u660E\uFF1AProperty that gives the name of the struct




\u7C7B\u578B\uFF1AStringProperty, \u53EA\u8BFB




## nested #




\u8BF4\u660E\uFF1AStruct in which this struct is always nested, and to which it logically belongs




\u7C7B\u578B\uFF1AStruct, \u53EA\u8BFB




## properties #




\u8BF4\u660E\uFF1AProperties in the struct




\u7C7B\u578B\uFF1Abpy_prop_collection of Property, \u53EA\u8BFB




## property_tags #




\u8BF4\u660E\uFF1ATags that properties can use to influence behavior




\u7C7B\u578B\uFF1Abpy_prop_collection of EnumPropertyItem, \u53EA\u8BFB




## translation_context #




\u8BF4\u660E\uFF1ATranslation context of the struct\u2019s name




\u7C7B\u578B\uFF1Astring, default \u201C\u201D, (\u53EA\u8BFB\uFF0C\u53EF\u9009)




## classmethod bl_rna_get_subclass() #




\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass(id, default=None)




\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.




\u8FD4\u56DE\uFF1ARNA\u7C7B\u578B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




\u8FD4\u56DE\u7C7B\u578B\uFF1Abpy.types.Struct subclass




## classmethod bl_rna_get_subclass_py() #




\u5168\u540D\uFF1Aclassmethod bl_rna_get_subclass_py(id, default=None)




\u53C2\u6570\uFF1Aid (\u5B57\u7B26\u4E32) \u3002 The RNA type identifier.




\u8FD4\u56DE\uFF1A\u7C7B\uFF0C\u672A\u627E\u5230\u5219\u4E3A\u9ED8\u8BA4\u3002




\u8FD4\u56DE\u7C7B\u578B\uFF1Atype
</code></pre>`,355);function V(w,U){const i=d("ExternalLinkIcon");return t(),l("div",null,[c,p,e("p",null,[e("a",b,[n("Attribute(bpy_struct)"),s(i)])]),e("p",null,[e("a",o,[n("AttributeGroup(bpy_struct)"),s(i)])]),v,e("p",null,[e("a",h,[n("Property(bpy_struct)"),s(i)])]),e("p",null,[e("a",m,[n("PropertyGroup(bpy_struct)"),s(i)])]),e("p",null,[e("a",y,[n("PropertyGroupItem(bpy_struct)"),s(i)])]),_,e("p",null,[e("a",f,[n("BoolAttribute(Attribute)"),s(i)])]),e("p",null,[e("a",g,[n("ByteColorAttribute(Attribute)"),s(i)])]),e("p",null,[e("a",A,[n("Float2Attribute(Attribute)"),s(i)])]),e("p",null,[e("a",N,[n("FloatAttribute(Attribute)"),s(i)])]),e("p",null,[e("a",x,[n("FloatColorAttribute(Attribute)"),s(i)])]),e("p",null,[e("a",R,[n("FloatVectorAttribute(Attribute)"),s(i)])]),e("p",null,[e("a",P,[n("IntAttribute(Attribute)"),s(i)])]),e("p",null,[e("a",T,[n("StringAttribute(Attribute)"),s(i)])]),E,e("p",null,[e("a",k,[n("BoolProperty(Property)"),s(i)])]),e("p",null,[e("a",F,[n("CollectionProperty(Property)"),s(i)])]),e("p",null,[e("a",S,[n("EnumProperty(Property)"),s(i)])]),e("p",null,[e("a",q,[n("FloatProperty(Property)"),s(i)])]),e("p",null,[e("a",I,[n("IntProperty(Property)"),s(i)])]),e("p",null,[e("a",O,[n("PointerProperty(Property)"),s(i)])]),e("p",null,[e("a",C,[n("StringProperty(Property)"),s(i)])]),e("p",null,[e("a",L,[n("Struct(bpy_struct)"),s(i)])]),e("p",null,[e("a",G,[n("EnumPropertyItem(bpy_struct)"),s(i)])]),M,e("p",null,[n("icon\uFF1A"),e("a",B,[n("\u7CFB\u7EDF\u56FE\u6807"),s(i)]),n("\u5217\u8868\u91CC\u4EFB\u9009\u4E00\u4E2A")]),D])}const H=r(u,[["render",V],["__file","Attribute Property + 8X2\u4E2A\u5C5E\u6027\u5B50\u7C7B.html.vue"]]);export{H as default};
